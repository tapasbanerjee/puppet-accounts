package com.view.vo;

public class FUWAnalysisVO {

    public FUWAnalysisVO() {
        super();
    }

    private FUWAnalysisVO.Customer customer;
    private FUWAnalysisVO.Bond bond;

    public void setCustomer(FUWAnalysisVO.Customer customer) {
        this.customer = customer;
    }

    public FUWAnalysisVO.Customer getCustomer() {
        return customer;
    }

    public void setBond(FUWAnalysisVO.Bond bond) {
        this.bond = bond;
    }

    public FUWAnalysisVO.Bond getBond() {
        return bond;
    }

    public static class Customer {

        private String company;
        private String customerContact;
        private String address;
        private String VATNumber;
        private String groupingId;
        private String status;

        public void setCompany(String company) {
            this.company = company;
        }

        public String getCompany() {
            return company;
        }

        public void setCustomerContact(String customerContact) {
            this.customerContact = customerContact;
        }

        public String getCustomerContact() {
            return customerContact;
        }

        public void setAddress(String address) {
            this.address = address;
        }

        public String getAddress() {
            return address;
        }

        public void setVATNumber(String VATNumber) {
            this.VATNumber = VATNumber;
        }

        public String getVATNumber() {
            return VATNumber;
        }

        public void setGroupingId(String groupingId) {
            this.groupingId = groupingId;
        }

        public String getGroupingId() {
            return groupingId;
        }

        public void setStatus(String status) {
            this.status = status;
        }

        public String getStatus() {
            return status;
        }
    }

    public static class Bond {

        private String bondClass;
        private String product;
        private String bondAmount;
        private String bondStartDate;
        private String bondEndDate;
        private String bondStandardText;
        private String bondCustomText;
        private String bondBeneficiaryName;

        private String bondExposureComments;
        private String bondMotive;
        private String bondDecisions;
        private String bondConditions;
        
        private String bondPolicyId;
        private String bondRequestDate;

        public void setBondClass(String bondClass) {
            this.bondClass = bondClass;
        }

        public String getBondClass() {
            return bondClass;
        }

        public void setProduct(String product) {
            this.product = product;
        }

        public String getProduct() {
            return product;
        }

        public void setBondAmount(String bondAmount) {
            this.bondAmount = bondAmount;
        }

        public String getBondAmount() {
            return bondAmount;
        }

        public void setBondStartDate(String bondStartDate) {
            this.bondStartDate = bondStartDate;
        }

        public String getBondStartDate() {
            return bondStartDate;
        }

        public void setBondEndDate(String bondEndDate) {
            this.bondEndDate = bondEndDate;
        }

        public String getBondEndDate() {
            return bondEndDate;
        }

        public void setBondStandardText(String bondStandardText) {
            this.bondStandardText = bondStandardText;
        }

        public String getBondStandardText() {
            return bondStandardText;
        }

        public void setBondCustomText(String bondCustomText) {
            this.bondCustomText = bondCustomText;
        }

        public String getBondCustomText() {
            return bondCustomText;
        }

        public void setBondBeneficiaryName(String bondBeneficiaryName) {
            this.bondBeneficiaryName = bondBeneficiaryName;
        }

        public String getBondBeneficiaryName() {
            return bondBeneficiaryName;
        }

        public void setBondExposureComments(String bondExposureComments) {
            this.bondExposureComments = bondExposureComments;
        }

        public String getBondExposureComments() {
            return bondExposureComments;
        }

        public void setBondMotive(String bondMotive) {
            this.bondMotive = bondMotive;
        }

        public String getBondMotive() {
            return bondMotive;
        }

        public void setBondDecisions(String bondDecisions) {
            this.bondDecisions = bondDecisions;
        }

        public String getBondDecisions() {
            return bondDecisions;
        }

        public void setBondConditions(String bondConditions) {
            this.bondConditions = bondConditions;
        }

        public String getBondConditions() {
            return bondConditions;
        }

        public void setBondPolicyId(String bondPolicyId) {
            this.bondPolicyId = bondPolicyId;
        }

        public String getBondPolicyId() {
            return bondPolicyId;
        }

        public void setBondRequestDate(String bondRequestDate) {
            this.bondRequestDate = bondRequestDate;
        }

        public String getBondRequestDate() {
            return bondRequestDate;
        }
    }
}
