package com.view.vo;

import java.util.ArrayList;
import java.util.List;

public class DashboardTaskListVO {
    public DashboardTaskListVO() {
        super();
    }
    
    private List<TaskListVO> completedTask = new ArrayList<TaskListVO>();
    private List<TaskListVO> openTask = new ArrayList<TaskListVO>();


    public void setCompletedTask(List<TaskListVO> completedTask) {
        this.completedTask = completedTask;
    }

    public List<TaskListVO> getCompletedTask() {
        return completedTask;
    }

    public void setOpenTask(List<TaskListVO> openTask) {
        this.openTask = openTask;
    }

    public List<TaskListVO> getOpenTask() {
        return openTask;
    }
}
