package com.view.dc;


import com.dashboard.Execute_ptt;
import com.dashboard.FetchDashboardSOAPService;
import com.dashboard.types.Analysis;
import com.dashboard.types.Analysis.UnderwriterOpinion;
import com.dashboard.types.Beneficiary;
import com.dashboard.types.Bond;
import com.dashboard.types.Policy;
import com.dashboard.types.ProcessResponseTaskDetails;
import com.dashboard.types.ProcessResponseTaskList;
import com.dashboard.types.ProcessTaskDetails;
import com.dashboard.types.ProcessTaskList;
import com.dashboard.types.Product;

import com.view.util.JSFUtils;
import com.view.vo.DashboardTaskListVO;
import com.view.vo.FUWAnalysisVO;
import com.view.vo.TaskListVO;

import java.math.BigDecimal;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import oracle.adf.share.ADFContext;
import oracle.adf.share.security.SecurityContext;


public class DashboardDC {

    private static FetchDashboardSOAPService proxyClient;

    public List<TaskListVO> findTaskDetails() {

        proxyClient = new FetchDashboardSOAPService();
        Execute_ptt execute_ptt = proxyClient.getExecute_pt();
        ProcessTaskList taskList = new ProcessTaskList();
        String userId = JSFUtils.resolveExpression("#{pageFlowScope.userId}").toString();
        taskList.setUserId(userId);
        ProcessResponseTaskList response = execute_ptt.getDashboardTaskList(taskList);
        List<ProcessResponseTaskList.TaxDutyBond> taxDutyBondList = response.getTaxDutyBond();

        List<TaskListVO> list = new ArrayList<TaskListVO>();

        for (ProcessResponseTaskList.TaxDutyBond taskDutyBond : taxDutyBondList) {
            TaskListVO taskListVO = new TaskListVO();
            taskListVO.setCustomerId(taskDutyBond.getCustomerBond().getCustomerId());
            taskListVO.setCustomerName(taskDutyBond.getCustomerBond().getCustomerName());
            List<Policy> policyList = taskDutyBond.getCustomerBond().getPolicyDtl();

            for (Policy policy : policyList) {
                taskListVO.setPolicyId(policy.getPolicyId());
                List<Bond> bondList = policy.getBondDtl();

                for (Bond bond : bondList) {
                    taskListVO.setBondId(bond.getBondId());
                    taskListVO.setRequestDate(bond.getBondRequestDate());
                    taskListVO.setBondStatus(bond.getBondStatus());
                    Product product = bond.getProductId();
                    taskListVO.setProduct(product.getProduct());
                    taskListVO.setBondAmount(product.getBondAmount());
                }
            }
            
            /**/
            
            taskListVO.setButtonType(taskDutyBond.getAdditionalADFInputs().getButtonType());
            
            /**/
            list.add(taskListVO);
        }
        
        //Sort on basis of decreasing bondId
        Comparator<TaskListVO> comparator = new Comparator<TaskListVO>() {
            @Override
            public int compare(TaskListVO left, TaskListVO right) {
                return right.getBondId().compareTo(left.getBondId());
            }
        };
        Collections.sort(list, comparator);
        //Sort on basis of decreasing bondId
        
        return list;
    }

    public List<TaskListVO> findTaskDetailsByTaskType(String taskType) {

        ADFContext adfCtx = ADFContext.getCurrent();
        SecurityContext secCntx = adfCtx.getSecurityContext();
        String user = secCntx.getUserPrincipal().getName();
        String _user = secCntx.getUserName();
        System.out.println("UserName==" + _user);
        
        if(!secCntx.isUserInRole("CustomerRole")) {
            proxyClient = new FetchDashboardSOAPService();
            Execute_ptt execute_ptt = proxyClient.getExecute_pt();
            ProcessTaskList taskList = new ProcessTaskList();
            String userId =
                JSFUtils.resolveExpression("#{pageFlowScope.userName}").toString();
            taskList.setUserId(userId);
            ProcessResponseTaskList response =
                execute_ptt.getDashboardTaskList(taskList);
            List<ProcessResponseTaskList.TaxDutyBond> taxDutyBondList =
                response.getTaxDutyBond();

            List<TaskListVO> list = new ArrayList<TaskListVO>();

            for (ProcessResponseTaskList.TaxDutyBond taskDutyBond :
                 taxDutyBondList) {
                TaskListVO taskListVO = new TaskListVO();
                taskListVO.setCustomerId(taskDutyBond.getCustomerBond().getCustomerId());
                taskListVO.setCustomerName(taskDutyBond.getCustomerBond().getCustomerName());
                List<Policy> policyList =
                    taskDutyBond.getCustomerBond().getPolicyDtl();

                for (Policy policy : policyList) {
                    taskListVO.setPolicyId(policy.getPolicyId());
                    List<Bond> bondList = policy.getBondDtl();

                    for (Bond bond : bondList) {
                        taskListVO.setBondId(bond.getBondId());
                        taskListVO.setRequestDate(bond.getBondRequestDate());
                        taskListVO.setBondStatus(bond.getBondStatus());
                        Product product = bond.getProductId();
                        taskListVO.setProduct(product.getProduct());
                        taskListVO.setBondAmount(product.getBondAmount());

                        //STUB TO DELETE//
                        //                    if(taskListVO.getBondAmount() == null || taskListVO.getBondAmount().trim().equals("")){
                        //                        taskListVO.setBondAmount("15000000");
                        //                    }
                        //                    if(taskListVO.getCustomerId() == null || "".equals(taskListVO.getCustomerId().trim())){
                        //                        if(Long.valueOf(taskListVO.getBondId()) % 2 == 0){
                        //                            taskListVO.setCustomerId("123");
                        //                        } else{
                        //                            taskListVO.setCustomerId("125");
                        //                        }
                        //                    }
                        //STUB TO DELETE//

                        if (taskListVO.getBondAmount() != null &&
                            !"".equals(taskListVO.getBondAmount().trim())) {
                            taskListVO.setBondAmountNumber(new BigDecimal(taskListVO.getBondAmount()));
                        } else {
                            taskListVO.setBondAmountNumber(new BigDecimal(0));
                        }
                    }
                }

                /**/
                String buttonType =
                    taskDutyBond.getAdditionalADFInputs().getButtonType();

                //STUB TO DELETE//
                //            if(Long.valueOf(taskListVO.getBondId()) % 2 == 0){
                //                buttonType = "ASSIGNED";
                //            }
                //STUB TO DELETE//
                taskListVO.setButtonType(buttonType);

                /**/
                if (buttonType.equals(taskType)) {
                    list.add(taskListVO);
                }
            }

            //Sort on basis of decreasing bondId
            Comparator<TaskListVO> comparator = new Comparator<TaskListVO>() {
                @Override
                public int compare(TaskListVO left, TaskListVO right) {
                    return right.getBondId().compareTo(left.getBondId());
                }
            };
            Collections.sort(list, comparator);
            //Sort on basis of decreasing bondId

            return list;
        } else {
            return null;
        }


    }

    public DashboardTaskListVO dashboardTaskList() {

        ADFContext adfCtx = ADFContext.getCurrent();
        SecurityContext secCntx = adfCtx.getSecurityContext();
        String user = secCntx.getUserPrincipal().getName();
        String _user = secCntx.getUserName();
        System.out.println("UserName==" + _user);
        
        if(!secCntx.isUserInRole("CustomerRole")) {
            proxyClient = new FetchDashboardSOAPService();
            Execute_ptt execute_ptt = proxyClient.getExecute_pt();
            ProcessTaskList taskList = new ProcessTaskList();
            String userId =
                JSFUtils.resolveExpression("#{pageFlowScope.userName}").toString();
            taskList.setUserId(userId);
            ProcessResponseTaskList response =
                execute_ptt.getDashboardTaskList(taskList);
            List<ProcessResponseTaskList.TaxDutyBond> taxDutyBondList =
                response.getTaxDutyBond();

            //List<TaskListVO> list = new ArrayList<TaskListVO>();
            
            DashboardTaskListVO dashboardTaskListVO = new DashboardTaskListVO();
            
            List<TaskListVO> openTasks = dashboardTaskListVO.getOpenTask();
            List<TaskListVO> completedTasks = dashboardTaskListVO.getCompletedTask();


            for (ProcessResponseTaskList.TaxDutyBond taskDutyBond :
                 taxDutyBondList) {
                TaskListVO taskListVO = new TaskListVO();
                taskListVO.setCustomerId(taskDutyBond.getCustomerBond().getCustomerId());
                taskListVO.setCustomerName(taskDutyBond.getCustomerBond().getCustomerName());
                List<Policy> policyList =
                    taskDutyBond.getCustomerBond().getPolicyDtl();

                for (Policy policy : policyList) {
                    taskListVO.setPolicyId(policy.getPolicyId());
                    List<Bond> bondList = policy.getBondDtl();

                    for (Bond bond : bondList) {
                        taskListVO.setBondId(bond.getBondId());
                        taskListVO.setRequestDate(bond.getBondRequestDate());
                        taskListVO.setBondStatus(bond.getBondStatus());
                        Product product = bond.getProductId();
                        taskListVO.setProduct(product.getProduct());
                        taskListVO.setBondAmount(product.getBondAmount());

                        if (taskListVO.getBondAmount() != null &&
                            !"".equals(taskListVO.getBondAmount().trim())) {
                            taskListVO.setBondAmountNumber(new BigDecimal(taskListVO.getBondAmount()));
                        } else {
                            taskListVO.setBondAmountNumber(new BigDecimal(0));
                        }
                    }
                }

                /**/
                String buttonType =
                    taskDutyBond.getAdditionalADFInputs().getButtonType();
                taskListVO.setButtonType(buttonType);

                /**/
                if (buttonType.equals("COMPLETED")) {
                    completedTasks.add(taskListVO);
                } else {
                    openTasks.add(taskListVO);
                }
            }

            //Sort on basis of decreasing bondId
            Comparator<TaskListVO> comparator = new Comparator<TaskListVO>() {
                @Override
                public int compare(TaskListVO left, TaskListVO right) {
                    return right.getBondId().compareTo(left.getBondId());
                }
            };
            Collections.sort(completedTasks, comparator);
            Collections.sort(openTasks, comparator);
            //Sort on basis of decreasing bondId

            return dashboardTaskListVO;
        } else {
            return null;
        }


    }

    public FUWAnalysisVO findFUWAnalysis() {

        proxyClient = new FetchDashboardSOAPService();
        Execute_ptt execute_ptt = proxyClient.getExecute_pt();
        ProcessTaskList taskList = new ProcessTaskList();
        String userId = JSFUtils.resolveExpression("#{pageFlowScope.userName}").toString();
        String bondId = JSFUtils.resolveExpression("#{pageFlowScope.bondId}").toString();
        taskList.setUserId(userId);
        ProcessResponseTaskList response = execute_ptt.getDashboardTaskList(taskList);
        List<ProcessResponseTaskList.TaxDutyBond> taxDutyBondList = response.getTaxDutyBond();

        FUWAnalysisVO fuwAnalysisVO = new FUWAnalysisVO();
        FUWAnalysisVO.Customer customerDetails = new FUWAnalysisVO.Customer();
        FUWAnalysisVO.Bond bondDetails = new FUWAnalysisVO.Bond();
        
        ProcessResponseTaskList.TaxDutyBond taxDutyBond = null;
        
        for(ProcessResponseTaskList.TaxDutyBond currentTaskDutyBond : taxDutyBondList){
            String currentTaskDutyBondId = currentTaskDutyBond.getAdditionalADFInputs().getBondId();
            
            if(currentTaskDutyBondId.equals(bondId)){
                taxDutyBond = currentTaskDutyBond;
                break;
            }
        }
        
        if(taxDutyBond != null){
            customerDetails.setCompany(taxDutyBond.getCustomerBond().getCustomerName());
            customerDetails.setAddress(taxDutyBond.getCustomerBond().getCustomerAddress());
            customerDetails.setCustomerContact(taxDutyBond.getCustomerBond().getCustomerContactName());
            customerDetails.setGroupingId(taxDutyBond.getCustomerBond().getCustomerId());
            customerDetails.setStatus(taxDutyBond.getCustomerBond().getCustomerStatus());
            customerDetails.setVATNumber(taxDutyBond.getCustomerBond().getCustomerVAT());
            
            List<Policy> policyList = taxDutyBond.getCustomerBond().getPolicyDtl();
            
            for (Policy policy : policyList) {
                List<Bond> bondList = policy.getBondDtl();
                
                bondDetails.setBondPolicyId(policy.getPolicyId());
                
                for (Bond bond : bondList) {
                    Product product = bond.getProductId();
                    bondDetails.setBondRequestDate(bond.getBondRequestDate());
                    bondDetails.setBondClass(product.getBondClass());
                    bondDetails.setProduct(product.getProduct());
                    bondDetails.setBondAmount(product.getBondAmount());
                    bondDetails.setBondCustomText(product.getBondCustomText());
                    bondDetails.setBondStandardText(product.getBondStandardText());
                    bondDetails.setBondStartDate(product.getBondStartDate());
                    bondDetails.setBondEndDate(product.getBondEndDate());

                    Beneficiary beneficiary = bond.getBeneficiary();
                    if(beneficiary != null){
                        bondDetails.setBondBeneficiaryName(beneficiary.getBeneficiaryCompanyName());                        
                    }
                }
            }

            if(taxDutyBond.getAnalysis() != null && taxDutyBond.getAnalysis().getUnderwriterOpinion() != null){
                UnderwriterOpinion opinion = taxDutyBond.getAnalysis().getUnderwriterOpinion();
                
                bondDetails.setBondExposureComments(opinion.getExposureComments());
                bondDetails.setBondMotive(opinion.getMotive());
                bondDetails.setBondConditions(opinion.getConditions());
                bondDetails.setBondDecisions(getValueFromLabel(opinion.getDecisions()));

            }
            
            
        }

//        for (ProcessResponseTaskDetails.TaxDutyBond taskDutyBond : taxDutyBondDetails) {
//            customer.setCompany(taskDutyBond.getCustomerBond().getCustomerName());
//            customer.setAddress(taskDutyBond.getCustomerBond().getCustomerAddress());
//            customer.setCustomerContact(taskDutyBond.getCustomerBond().getCustomerContactName());
//            customer.setGroupingId(taskDutyBond.getCustomerBond().getCustomerId());
//            customer.setStatus(taskDutyBond.getCustomerBond().getCustomerStatus());
//            customer.setVATNumber(taskDutyBond.getCustomerBond().getCustomerVAT());
//            List<Policy> policyList = taskDutyBond.getCustomerBond().getPolicyDtl();
//
//            for (Policy policy : policyList) {
//                List<Bond> bondList = policy.getBondDtl();
//                
//                for (Bond bond : bondList) {
//                    Product product = bond.getProductId();
//                    customerBond.setBondClass(product.getBondClass());
//                    customerBond.setProduct(product.getProduct());
//                    customerBond.setBondAmount(product.getBondAmount());
//                    customerBond.setBondCustomText(product.getBondCustomText());
//                    customerBond.setBondStandardText(product.getBondStandardText());
//                    customerBond.setBondStartDate(product.getBondStartDate());
//                    customerBond.setBondEndDate(product.getBondEndDate());
//
//                    Beneficiary beneficiary = bond.getBeneficiary();
//                    if(beneficiary != null){
//                        customerBond.setBondBeneficiaryName(beneficiary.getBeneficiaryCompanyName());                        
//                    }
//                }
//            }
//        }
        fuwAnalysisVO.setCustomer(customerDetails);
        fuwAnalysisVO.setBond(bondDetails);
        return fuwAnalysisVO;
    }
    
    private String getValueFromLabel(Object value) {

        if (value != null) {
            if (value.equals("APPROVED AS SUBMITTED"))
                return "1";
            if (value.equals("APPROVED WITH MODIFICATIONS"))
                return "2";
            if (value.equals("REFUSED"))
                return "3";
            if (value.equals("WAITING FOR INFORMATION"))
                return "4";
        }
        return "4";
    }
}
