package com.view.bean;

import java.util.ArrayList;
import java.util.List;

import oracle.adf.view.rich.component.rich.data.RichTable;
import oracle.adf.view.rich.context.AdfFacesContext;

import org.apache.myfaces.trinidad.event.SortEvent;
import org.apache.myfaces.trinidad.model.SortCriterion;

public class DashboardBean {

    private RichTable openTable;
    private RichTable completedTable;

    public DashboardBean() {
        System.out.println("TEST");
    }

    public void openTableSort(SortEvent sortEvent) {

        List sortList = sortEvent.getSortCriteria();
        SortCriterion sc = (SortCriterion)sortList.get(0);
        boolean order = sc.isAscending();

        System.out.println(sc.getProperty());
        System.out.println(order);

        sortList = new ArrayList();

        // In the sort criteria parameters set the column by
        // which you would like to sort and the order (asc, desc)
        // pass true if you want to sort in the ascending order
        // and false otherwise
        String sortCol = sc.getProperty().toString();

        // Create the desired search criteria here
        SortCriterion sc2 = new SortCriterion(sortCol, order);
        sortList.add(sc2);
        this.getOpenTable().setSortCriteria(sortList);

        // Refresh the table after applying the sort criteria
        AdfFacesContext.getCurrentInstance().addPartialTarget(getOpenTable());
    }
    
    public void completedTableSort(SortEvent sortEvent) {

        List sortList = sortEvent.getSortCriteria();
        SortCriterion sc = (SortCriterion)sortList.get(0);
        boolean order = sc.isAscending();

        System.out.println(sc.getProperty());
        System.out.println(order);

        sortList = new ArrayList();

        // In the sort criteria parameters set the column by
        // which you would like to sort and the order (asc, desc)
        // pass true if you want to sort in the ascending order
        // and false otherwise
        String sortCol = sc.getProperty().toString();

        // Create the desired search criteria here
        SortCriterion sc2 = new SortCriterion(sortCol, order);
        sortList.add(sc2);
        this.getOpenTable().setSortCriteria(sortList);

        // Refresh the table after applying the sort criteria
        AdfFacesContext.getCurrentInstance().addPartialTarget(getCompletedTable());
    }

    public void setOpenTable(RichTable openTable) {
        this.openTable = openTable;
    }

    public RichTable getOpenTable() {
        return openTable;
    }

    public void setCompletedTable(RichTable completedTable) {
        this.completedTable = completedTable;
    }

    public RichTable getCompletedTable() {
        return completedTable;
    }
}
