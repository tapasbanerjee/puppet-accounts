package com.view.bean;


import com.updatetask.Execute_ptt;
import com.updatetask.UpdateTaskActivityWS;
import com.updatetask.types.ADFInputType;
import com.updatetask.types.Analysis;
import com.updatetask.types.Bond;
import com.updatetask.types.BondLineParameter;
import com.updatetask.types.BondLineParameterType;
import com.updatetask.types.CurrentBondingExposure;
import com.updatetask.types.Customer;
import com.updatetask.types.EconomicalAnalysis;
import com.updatetask.types.Exposure;
import com.updatetask.types.Policy;
import com.updatetask.types.ProcessResponse;
import com.updatetask.types.Product;
import com.updatetask.types.ReviewLimit;
import com.updatetask.types.ReviewLimitType;
import com.updatetask.types.ReviewType;
import com.updatetask.types.TaxDutyBond;

import com.view.util.JSFUtils;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;

import javax.faces.event.ValueChangeEvent;

import oracle.adf.model.BindingContext;
import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCIteratorBinding;
import oracle.adf.share.ADFContext;
import oracle.adf.view.rich.component.rich.RichPopup;
import oracle.adf.view.rich.component.rich.input.RichInputText;
import oracle.adf.view.rich.component.rich.input.RichSelectOneChoice;

import oracle.binding.OperationBinding;

import oracle.jbo.Row;
import oracle.jbo.RowSetIterator;
import oracle.jbo.ViewObject;


public class FUWAnalysisBean {

    private static UpdateTaskActivityWS proxyClient;
    private RichSelectOneChoice decision;
    private RichPopup submitConfirmPopUp;
    private RichPopup submitPopUp;
    private RichInputText currentExposureComments;
    private RichInputText requestComments;
    private RichInputText conditionsComment;

    public FUWAnalysisBean() {

        proxyClient = new UpdateTaskActivityWS();
    }

    public String submit() {

        this.getSubmitConfirmPopUp().hide();

        Execute_ptt execute_ptt = proxyClient.getExecute_pt();
        TaxDutyBond taxDutyBond = new TaxDutyBond();
        
        String userName = JSFUtils.resolveExpression("#{pageFlowScope.userName}").toString();
        String userRole = JSFUtils.resolveExpression("#{pageFlowScope.userRole}").toString();
        String bondId = JSFUtils.resolveExpression("#{pageFlowScope.bondId}").toString();
        String bondStatus = JSFUtils.resolveExpression("#{pageFlowScope.bondStatus}").toString();
        String bondAmount = JSFUtils.resolveExpression("#{pageFlowScope.bondAmount}").toString();

        if (bondStatus.equalsIgnoreCase("ON HOLD")) {
            raiseFacesMessage(FacesMessage.SEVERITY_WARN, "Task cannot be submitted since it is On Hold");
            return null;
        }
        
        if(!"".equals(checkComments())){
            raiseFacesMessage(FacesMessage.SEVERITY_ERROR, checkComments());
            return null;
        }

        if (getDecision().getValue() == null) {
            raiseFacesMessage(FacesMessage.SEVERITY_ERROR, "Please provide Underwriter Decision to submit the task");
            return null;
        }
        
//        ADFInputType adfInputType = new ADFInputType();
//        adfInputType.setBondId(bondId);
//        adfInputType.setButtonType("SUBMIT");
//        adfInputType.setUserId(userName);
//        adfInputType.setUserRole(userRole);
//        taxDutyBond.setAdditionalADFInputs(adfInputType);
//
//        Customer customer = new Customer();
//        List<Policy> policyList = customer.getPolicyDtl();
//        Policy policy = new Policy();
//        List<Bond> bondList = policy.getBondDtl();
//
//        Analysis analysis = new Analysis();
//        Analysis.UnderwriterOpinion opinion = new Analysis.UnderwriterOpinion();
//        opinion.setDecisions(getLabel(getDecision().getValue()));
//        analysis.setUnderwriterOpinion(opinion);
//        taxDutyBond.setAnalysis(analysis);
//
//        Bond bond = new Bond();
//        Product product = new Product();
//        product.setBondAmount(bondAmount);
//        bond.setBondId(bondId);
//        if (bondStatus.equalsIgnoreCase("REQUESTED") && userRole.equalsIgnoreCase("TUW"))
//            bond.setBondStatus("APPROVED");
//        //else if (bondStatus.equalsIgnoreCase("REQUESTED") && userRole.equalsIgnoreCase("FUW"))
//        //    bond.setBondStatus("INTERIM APPROVED");
//        else
//            bond.setBondStatus(bondStatus);
//        bond.setProductId(product);
//        bondList.add(bond);
//        policyList.add(policy);
//
//        customer.setCustomerId(userName);
//        taxDutyBond.setCustomerBond(customer);
        
        taxDutyBond = getWSObjectForSave("SUBMIT");
//        if(1 == 1)
//            return null;

        ProcessResponse processResponse = execute_ptt.execute(taxDutyBond);
        System.out.println(processResponse.getResult());
        
        saveHistory(getLabel(getDecision().getValue()));
        
        if (processResponse.getResult().equalsIgnoreCase("SUCCESS")) {
            RichPopup.PopupHints hints = new RichPopup.PopupHints();
            
            OperationBinding op = BindingContext.getCurrent().getCurrentBindingsEntry().getOperationBinding("Commit");
            op.execute();
            
            this.getSubmitPopUp().show(hints);
        } else {
            raiseFacesMessage(FacesMessage.SEVERITY_WARN, processResponse.getResult());
        }
        
        return "return";
    }

    public String getLabel(Object value) {

        if (value != null) {
            if (value.equals("1"))
                return "APPROVED AS SUBMITTED";
            if (value.equals("2"))
                return "APPROVED WITH MODIFICATIONS";
            if (value.equals("3"))
                return "REFUSED";
            if (value.equals("4"))
                return "WAITING FOR INFORMATION";
        }
        return null;
    }
    
    public String checkComments(){
        String commentsException = "";
        if(getCurrentExposureComments().getValue() ==  null || "".equals(getCurrentExposureComments().getValue())){
            commentsException = "Comments on Current Exposure is mandatory.";
        } else if(getRequestComments().getValue() ==  null || "".equals(getRequestComments().getValue())){
            commentsException = "Motive/Comments on Request is mandatory.";
        } else if(getConditionsComment().getValue() ==  null || "".equals(getConditionsComment().getValue())){
            commentsException = "Conditions is mandatory.";
        }
        return commentsException;
    }

    public void confirmSubmit(ActionEvent actionEvent) {

        RichPopup.PopupHints hints = new RichPopup.PopupHints();
        this.getSubmitConfirmPopUp().show(hints);
    }

    public TaxDutyBond getWSObjectForSave(String operation){
        
        String userName = JSFUtils.resolveExpression("#{pageFlowScope.userName}").toString();
        String userRole = JSFUtils.resolveExpression("#{pageFlowScope.userRole}").toString();
        String bondId = JSFUtils.resolveExpression("#{pageFlowScope.bondId}").toString();
        String bondStatus = JSFUtils.resolveExpression("#{pageFlowScope.bondStatus}").toString();
        String bondAmount = JSFUtils.resolveExpression("#{pageFlowScope.bondAmount}").toString();
        
        TaxDutyBond taxDutyBond = new TaxDutyBond();
        
        ADFInputType adfInputType = new ADFInputType();
        
        adfInputType.setBondId(bondId);
        adfInputType.setButtonType(operation);
        adfInputType.setUserId(userName);
        adfInputType.setUserRole(userRole);
        taxDutyBond.setAdditionalADFInputs(adfInputType);
        
        DCIteratorBinding customerIter = ((DCBindingContainer)BindingContext.getCurrent().getCurrentBindingsEntry()).findIteratorBinding("customerIterator");
        Row currentCustomerRow = customerIter.getCurrentRow();
        
        Customer customer = new Customer();
        
        if(currentCustomerRow != null){
            customer.setCustomerId((String)currentCustomerRow.getAttribute("groupingId"));
            customer.setCustomerName((String)currentCustomerRow.getAttribute("company"));
            customer.setCustomerAddress((String)currentCustomerRow.getAttribute("address"));
            customer.setCustomerContactName((String)currentCustomerRow.getAttribute("customerContact"));
            customer.setCustomerVAT((String)currentCustomerRow.getAttribute("VATNumber"));
            customer.setCustomerStatus((String)currentCustomerRow.getAttribute("status"));
        }
        
        DCIteratorBinding bondIterator = ((DCBindingContainer)BindingContext.getCurrent().getCurrentBindingsEntry()).findIteratorBinding("bondIterator");
        Row bondCustomerRow = bondIterator.getCurrentRow();
        
        Bond bond = new Bond();
        
        List<Policy> policyList = customer.getPolicyDtl();
        Policy policy = new Policy();
        List<Bond> bondList = policy.getBondDtl();
        
        if(bondCustomerRow != null){
            bond.setBondId(bondId);
            bond.setBondStatus(bondStatus);
            bond.setBondRequestDate((String)bondCustomerRow.getAttribute("bondRequestDate"));
            
            policy.setPolicyId((String)bondCustomerRow.getAttribute("bondPolicyId"));
            
            Product product = new Product();
            product.setBondAmount(bondAmount);
            product.setBondClass((String)bondCustomerRow.getAttribute("bondClass"));
            product.setProduct((String)bondCustomerRow.getAttribute("product"));
            product.setBondStartDate((String)bondCustomerRow.getAttribute("bondStartDate"));
            product.setBondEndDate((String)bondCustomerRow.getAttribute("bondEndDate"));
            product.setBondStandardText((String)bondCustomerRow.getAttribute("bondStandardText"));
            
            bond.setProductId(product);
        }
        bondList.add(bond);
        policyList.add(policy);
        
        Analysis analysis = new Analysis();
        
        analysis.setBondId(bondId);
        analysis.setAnalysisId(bondId);
        
        Analysis.UnderwriterOpinion opinion = new Analysis.UnderwriterOpinion();
        opinion.setDecisions(getLabel(getDecision().getValue()));
        opinion.setExposureComments(getCurrentExposureComments().getValue().toString());
        opinion.setMotive(getRequestComments().getValue().toString());
        opinion.setConditions(getConditionsComment().getValue().toString());
        
        analysis.setUnderwriterOpinion(opinion);
        
        DCIteratorBinding analysisIterator = ((DCBindingContainer)BindingContext.getCurrent().getCurrentBindingsEntry()).findIteratorBinding("AnalysisView1Iterator");
        Row analysisIteratorRow = analysisIterator.getCurrentRow();
        
        if(analysisIteratorRow != null){
            BondLineParameter blp = new BondLineParameter();
            
            BondLineParameterType blpt = new BondLineParameterType();
            blpt.setBondLineAmount((String)analysisIteratorRow.getAttribute("Bla"));
            
            blp.setCurrentBLP(blpt);
            
            analysis.setBondLineParameters(blp);
        }
        
        
        DCIteratorBinding economicalAnalysisIterator = ((DCBindingContainer)BindingContext.getCurrent().getCurrentBindingsEntry()).findIteratorBinding("EconomicalAnalysisVOIterator");
        Row economicalAnalysisIteratorRow = economicalAnalysisIterator.getCurrentRow();
        
        if(economicalAnalysisIteratorRow != null){
            EconomicalAnalysis ea = new EconomicalAnalysis();
            
            ea.setCreationDate((String)economicalAnalysisIteratorRow.getAttribute("CreationDate"));
            ea.setLegalForm((String)economicalAnalysisIteratorRow.getAttribute("LegalForm"));
            ea.setShareHolder((String)economicalAnalysisIteratorRow.getAttribute("Salesholders"));
            ea.setHistory((String)economicalAnalysisIteratorRow.getAttribute("History"));
            ea.setGroupActivity((String)economicalAnalysisIteratorRow.getAttribute("GroupActivity"));
            ea.setMarketStudy((String)economicalAnalysisIteratorRow.getAttribute("MarketStudy"));
            ea.setExtraInfo((String)economicalAnalysisIteratorRow.getAttribute("ExtraInfo"));
            ea.setPerspectiveForNextPeriod((String)economicalAnalysisIteratorRow.getAttribute("NextPeriod"));
            ea.setProvisionalSales((String)economicalAnalysisIteratorRow.getAttribute("ProvisionalSales"));
            ea.setInvestmentsAndProject((String)economicalAnalysisIteratorRow.getAttribute("InvestmentProject"));
            ea.setOpinionFinReports((String)economicalAnalysisIteratorRow.getAttribute("LastFinReport"));
            ea.setExternalSources((String)economicalAnalysisIteratorRow.getAttribute("ExternalSource"));
            ea.setStrengths((String)economicalAnalysisIteratorRow.getAttribute("Strengths"));
            ea.setWeakness((String)economicalAnalysisIteratorRow.getAttribute("Weakness"));
            
            analysis.setEconomicalAnalysis(ea);
        }
        
        DCIteratorBinding reviewLimitsIterator = ((DCBindingContainer)BindingContext.getCurrent().getCurrentBindingsEntry()).findIteratorBinding("ProductViewView1Iterator");
        RowSetIterator reviewLimitsRsit = reviewLimitsIterator.getRowSetIterator();
        
        ReviewLimit reviewLimit = new ReviewLimit();
        ReviewLimitType currentReviewLimit = new ReviewLimitType();
        reviewLimit.setCurrentReviewLimit(currentReviewLimit);
        List<ReviewType> bondCls = currentReviewLimit.getBondClass();

        ReviewType reviewType = new ReviewType();
        bondCls.add(reviewType);

        while(reviewLimitsRsit != null && reviewLimitsRsit.hasNext()){

            Row reviewLimitsIteratorRow = reviewLimitsRsit.next();

            oracle.jbo.domain.Number ProdReviewLimit = (oracle.jbo.domain.Number)reviewLimitsIteratorRow.getAttribute("ProdReviewLimit");
            
            ReviewType.Product reviewTypeProduct = new ReviewType.Product();
            reviewTypeProduct.setProductName((String)reviewLimitsIteratorRow.getAttribute("ProductName"));
            reviewTypeProduct.setProductReviewLimitAmount(ProdReviewLimit != null ? ProdReviewLimit.toString() : "");

            reviewType.getProduct().add(reviewTypeProduct);
            currentReviewLimit.setNextReviewDate((String)reviewLimitsIteratorRow.getAttribute("ReviewDate"));

        }

        analysis.setReviewLimits(reviewLimit);
        
        
        DCIteratorBinding bondExposureIterator = ((DCBindingContainer)BindingContext.getCurrent().getCurrentBindingsEntry()).findIteratorBinding("BondExposureView1Iterator");
        RowSetIterator bondExposureRsit = bondExposureIterator.getRowSetIterator();

        CurrentBondingExposure bondingExposure = new CurrentBondingExposure();
        Exposure bondClass = new Exposure();
        List<Exposure.Product> exposureProductList = bondClass.getProduct();
        
        while(bondExposureRsit != null && bondExposureRsit.hasNext()){
            
            Row bondExposureIteratorRow = bondExposureRsit.next();
            
            Exposure.Product exposureProduct = new Exposure.Product();
            
            exposureProduct.setProductName((String)bondExposureIteratorRow.getAttribute("Productname"));
            
            oracle.jbo.domain.Number Bondingexposure = (oracle.jbo.domain.Number)bondExposureIteratorRow.getAttribute("Bondingexposure");
            exposureProduct.setProductExposureAmount(Bondingexposure != null ? Bondingexposure.toString() : "");
            
            bondingExposure.setGlobalBondingExposure((String)bondExposureIteratorRow.getAttribute("Classname"));
            
            exposureProductList.add(exposureProduct);
        }
        bondingExposure.setBondClass(bondClass);
        
        analysis.setCurrentBondingExposure(bondingExposure);
        
        
        taxDutyBond.setAnalysis(analysis);
        
        taxDutyBond.setCustomerBond(customer);

        return taxDutyBond;
    }
    
    public String save() {

        Execute_ptt execute_ptt = proxyClient.getExecute_pt();
        TaxDutyBond taxDutyBond = new TaxDutyBond();
        
        if(!"".equals(checkComments())){
            raiseFacesMessage(FacesMessage.SEVERITY_ERROR, checkComments());
            return null;
        }

        if (getDecision().getValue() == null) {
            raiseFacesMessage(FacesMessage.SEVERITY_ERROR, "Please provide Underwriter Decision to submit the task");
            return null;
        }

//        ADFInputType adfInputType = new ADFInputType();
//        adfInputType.setBondId(bondId);
//        adfInputType.setButtonType("SAVE");
//        adfInputType.setUserId(userName);
//        adfInputType.setUserRole(userRole);
//        taxDutyBond.setAdditionalADFInputs(adfInputType);
//
//        Customer customer = new Customer();
//        List<Policy> policyList = customer.getPolicyDtl();
//        Policy policy = new Policy();
//        List<Bond> bondList = policy.getBondDtl();
//
//        Bond bond = new Bond();
//        Product product = new Product();
//        product.setBondAmount(bondAmount);
//        bond.setProductId(product);
//        bond.setBondId(bondId);
//        bond.setBondStatus(bondStatus);
//        bondList.add(bond);
//        policyList.add(policy);
//
//        customer.setCustomerId(userName);
//        taxDutyBond.setCustomerBond(customer);
        
        taxDutyBond = getWSObjectForSave("SAVE");
//        if(1 == 1)
//            return null;

        ProcessResponse processResponse = execute_ptt.execute(taxDutyBond);

        if (processResponse.getResult().equalsIgnoreCase("SUCCESS")) {
        
            OperationBinding op = BindingContext.getCurrent().getCurrentBindingsEntry().getOperationBinding("Commit");
            op.execute();
            
            raiseFacesMessage(FacesMessage.SEVERITY_INFO, "Data Saved Successfully");
        } else {
            raiseFacesMessage(FacesMessage.SEVERITY_WARN, processResponse.getResult());
        }
        
        return "return";
    }

    public void cancelConfirmPopUp(ActionEvent actionEvent) {

        this.getSubmitConfirmPopUp().hide();
    }

    public void okCancelPopUp(ActionEvent actionEvent) {

        this.getSubmitPopUp().hide();
    }

    public ViewObject getViewObject(String iterator) {

        DCBindingContainer bindings = (DCBindingContainer)BindingContext.getCurrent().getCurrentBindingsEntry();
        DCIteratorBinding dcItrBindings = bindings.findIteratorBinding(iterator);
        return dcItrBindings.getViewObject();
    }

    public static void raiseFacesMessage(javax.faces.application.FacesMessage.Severity severity, String msg) {

        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(severity, null, msg));
    }

    public void setDecision(RichSelectOneChoice decision) {
        this.decision = decision;
    }

    public RichSelectOneChoice getDecision() {
        return decision;
    }

    public void setSubmitConfirmPopUp(RichPopup submitPopUp) {
        this.submitConfirmPopUp = submitPopUp;
    }

    public RichPopup getSubmitConfirmPopUp() {
        return submitConfirmPopUp;
    }

    public void setSubmitPopUp(RichPopup submitPopUp) {
        this.submitPopUp = submitPopUp;
    }

    public RichPopup getSubmitPopUp() {
        return submitPopUp;
    }
        
    public void underWriterDecisionChangeListener(ValueChangeEvent ve){
        String selectValue = (String)ve.getNewValue();
        
        if(selectValue!=null && "WAITING FOR INFORMATION".equalsIgnoreCase(getLabel(selectValue))){
            ADFContext.getCurrent().getViewScope().put("submitDisabled", true);
        } else {
            ADFContext.getCurrent().getViewScope().put("submitDisabled", false);
        }
        
    }
    
    public void saveHistory(String decision){
        ViewObject vo = getViewObject("HistoryView1Iterator");

        Row createRow = vo.createRow();
        
        createRow.setAttribute("UserId", ADFContext.getCurrent().getPageFlowScope().get("userId"));
        createRow.setAttribute("BondId", ADFContext.getCurrent().getPageFlowScope().get("bondId"));
        createRow.setAttribute("Decision", decision);
        createRow.setAttribute("DecisionDate", new Date());
        
        vo.insertRow(createRow);
    }

    public void setCurrentExposureComments(RichInputText currentExposureComments) {
        this.currentExposureComments = currentExposureComments;
    }

    public RichInputText getCurrentExposureComments() {
        return currentExposureComments;
    }

    public void setRequestComments(RichInputText requestComments) {
        this.requestComments = requestComments;
    }

    public RichInputText getRequestComments() {
        return requestComments;
    }

    public void setConditionsComment(RichInputText conditionsComment) {
        this.conditionsComment = conditionsComment;
    }

    public RichInputText getConditionsComment() {
        return conditionsComment;
    }
}
