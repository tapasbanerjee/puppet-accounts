package com.view.vo;

import java.math.BigDecimal;

public class TaskListVO {

    private String requestDate;
    private String customerId;
    private String customerName;
    private String policyId;
    private String bondId;
    private String product;
    private String bondAmount;
    private String bondStatus;
    private String buttonType;
    private BigDecimal bondAmountNumber;

    public TaskListVO() {
        super();
    }

    public void setRequestDate(String requestDate) {
        this.requestDate = requestDate;
    }

    public String getRequestDate() {
        return requestDate;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setPolicyId(String policyId) {
        this.policyId = policyId;
    }

    public String getPolicyId() {
        return policyId;
    }

    public void setBondId(String bondId) {
        this.bondId = bondId;
    }

    public String getBondId() {
        return bondId;
    }

    public void setProduct(String product) {
        this.product = product;
    }

    public String getProduct() {
        return product;
    }

    public void setBondAmount(String bondAmount) {
        this.bondAmount = bondAmount;
    }

    public String getBondAmount() {
        return bondAmount;
    }

    public void setBondStatus(String bondStatus) {
        this.bondStatus = bondStatus;
    }

    public String getBondStatus() {
        return bondStatus;
    }

    public void setButtonType(String buttonType) {
        this.buttonType = buttonType;
    }

    public String getButtonType() {
        return buttonType;
    }

    public void setBondAmountNumber(BigDecimal bondAmountNumber) {
        this.bondAmountNumber = bondAmountNumber;
    }

    public BigDecimal getBondAmountNumber() {
        return bondAmountNumber;
    }
}
