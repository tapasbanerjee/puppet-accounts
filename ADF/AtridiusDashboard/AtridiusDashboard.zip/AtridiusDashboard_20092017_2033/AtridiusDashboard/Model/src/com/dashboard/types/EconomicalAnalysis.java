
package com.dashboard.types;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for EconomicalAnalysis complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="EconomicalAnalysis">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="CreationDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="LegalForm" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ShareHolder" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="History" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="GroupActivity" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="MarketStudy" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ExtraInfo" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="OpinionFinReports" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="OpinionFinElements" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="PerspectiveForNextPeriod" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ProvisionalSales" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="InvestmentsAndProject" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ExternalSources" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Strengths" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Weakness" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "EconomicalAnalysis", propOrder = {
    "creationDate",
    "legalForm",
    "shareHolder",
    "history",
    "groupActivity",
    "marketStudy",
    "extraInfo",
    "opinionFinReports",
    "opinionFinElements",
    "perspectiveForNextPeriod",
    "provisionalSales",
    "investmentsAndProject",
    "externalSources",
    "strengths",
    "weakness"
})
public class EconomicalAnalysis {

    @XmlElement(name = "CreationDate", required = true)
    protected String creationDate;
    @XmlElement(name = "LegalForm", required = true)
    protected String legalForm;
    @XmlElement(name = "ShareHolder", required = true)
    protected String shareHolder;
    @XmlElement(name = "History", required = true)
    protected String history;
    @XmlElement(name = "GroupActivity", required = true)
    protected String groupActivity;
    @XmlElement(name = "MarketStudy", required = true)
    protected String marketStudy;
    @XmlElement(name = "ExtraInfo", required = true)
    protected String extraInfo;
    @XmlElement(name = "OpinionFinReports", required = true)
    protected String opinionFinReports;
    @XmlElement(name = "OpinionFinElements", required = true)
    protected String opinionFinElements;
    @XmlElement(name = "PerspectiveForNextPeriod", required = true)
    protected String perspectiveForNextPeriod;
    @XmlElement(name = "ProvisionalSales", required = true)
    protected String provisionalSales;
    @XmlElement(name = "InvestmentsAndProject", required = true)
    protected String investmentsAndProject;
    @XmlElement(name = "ExternalSources", required = true)
    protected String externalSources;
    @XmlElement(name = "Strengths", required = true)
    protected String strengths;
    @XmlElement(name = "Weakness", required = true)
    protected String weakness;

    /**
     * Gets the value of the creationDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCreationDate() {
        return creationDate;
    }

    /**
     * Sets the value of the creationDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCreationDate(String value) {
        this.creationDate = value;
    }

    /**
     * Gets the value of the legalForm property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLegalForm() {
        return legalForm;
    }

    /**
     * Sets the value of the legalForm property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLegalForm(String value) {
        this.legalForm = value;
    }

    /**
     * Gets the value of the shareHolder property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getShareHolder() {
        return shareHolder;
    }

    /**
     * Sets the value of the shareHolder property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setShareHolder(String value) {
        this.shareHolder = value;
    }

    /**
     * Gets the value of the history property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHistory() {
        return history;
    }

    /**
     * Sets the value of the history property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHistory(String value) {
        this.history = value;
    }

    /**
     * Gets the value of the groupActivity property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGroupActivity() {
        return groupActivity;
    }

    /**
     * Sets the value of the groupActivity property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGroupActivity(String value) {
        this.groupActivity = value;
    }

    /**
     * Gets the value of the marketStudy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMarketStudy() {
        return marketStudy;
    }

    /**
     * Sets the value of the marketStudy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMarketStudy(String value) {
        this.marketStudy = value;
    }

    /**
     * Gets the value of the extraInfo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExtraInfo() {
        return extraInfo;
    }

    /**
     * Sets the value of the extraInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExtraInfo(String value) {
        this.extraInfo = value;
    }

    /**
     * Gets the value of the opinionFinReports property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOpinionFinReports() {
        return opinionFinReports;
    }

    /**
     * Sets the value of the opinionFinReports property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOpinionFinReports(String value) {
        this.opinionFinReports = value;
    }

    /**
     * Gets the value of the opinionFinElements property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOpinionFinElements() {
        return opinionFinElements;
    }

    /**
     * Sets the value of the opinionFinElements property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOpinionFinElements(String value) {
        this.opinionFinElements = value;
    }

    /**
     * Gets the value of the perspectiveForNextPeriod property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPerspectiveForNextPeriod() {
        return perspectiveForNextPeriod;
    }

    /**
     * Sets the value of the perspectiveForNextPeriod property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPerspectiveForNextPeriod(String value) {
        this.perspectiveForNextPeriod = value;
    }

    /**
     * Gets the value of the provisionalSales property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProvisionalSales() {
        return provisionalSales;
    }

    /**
     * Sets the value of the provisionalSales property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProvisionalSales(String value) {
        this.provisionalSales = value;
    }

    /**
     * Gets the value of the investmentsAndProject property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInvestmentsAndProject() {
        return investmentsAndProject;
    }

    /**
     * Sets the value of the investmentsAndProject property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInvestmentsAndProject(String value) {
        this.investmentsAndProject = value;
    }

    /**
     * Gets the value of the externalSources property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExternalSources() {
        return externalSources;
    }

    /**
     * Sets the value of the externalSources property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExternalSources(String value) {
        this.externalSources = value;
    }

    /**
     * Gets the value of the strengths property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStrengths() {
        return strengths;
    }

    /**
     * Sets the value of the strengths property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStrengths(String value) {
        this.strengths = value;
    }

    /**
     * Gets the value of the weakness property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWeakness() {
        return weakness;
    }

    /**
     * Sets the value of the weakness property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWeakness(String value) {
        this.weakness = value;
    }

}
