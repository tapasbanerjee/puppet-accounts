
package com.updatetask.types;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ReviewLimit complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ReviewLimit">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="CurrentReviewLimit" type="{https://group.atradius.com}ReviewLimitType"/>
 *         &lt;element name="ProposedReviewLimit" type="{https://group.atradius.com}ReviewLimitType"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ReviewLimit", propOrder = {
    "currentReviewLimit",
    "proposedReviewLimit"
})
public class ReviewLimit {

    @XmlElement(name = "CurrentReviewLimit", required = true)
    protected ReviewLimitType currentReviewLimit;
    @XmlElement(name = "ProposedReviewLimit", required = true)
    protected ReviewLimitType proposedReviewLimit;

    /**
     * Gets the value of the currentReviewLimit property.
     * 
     * @return
     *     possible object is
     *     {@link ReviewLimitType }
     *     
     */
    public ReviewLimitType getCurrentReviewLimit() {
        return currentReviewLimit;
    }

    /**
     * Sets the value of the currentReviewLimit property.
     * 
     * @param value
     *     allowed object is
     *     {@link ReviewLimitType }
     *     
     */
    public void setCurrentReviewLimit(ReviewLimitType value) {
        this.currentReviewLimit = value;
    }

    /**
     * Gets the value of the proposedReviewLimit property.
     * 
     * @return
     *     possible object is
     *     {@link ReviewLimitType }
     *     
     */
    public ReviewLimitType getProposedReviewLimit() {
        return proposedReviewLimit;
    }

    /**
     * Sets the value of the proposedReviewLimit property.
     * 
     * @param value
     *     allowed object is
     *     {@link ReviewLimitType }
     *     
     */
    public void setProposedReviewLimit(ReviewLimitType value) {
        this.proposedReviewLimit = value;
    }

}
