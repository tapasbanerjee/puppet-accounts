
package com.updatetask.types;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ADFInputType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ADFInputType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="UserId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="UserRole" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="BondId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ButtonType" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ADFInputType", propOrder = {
    "userId",
    "userRole",
    "bondId",
    "buttonType"
})
public class ADFInputType {

    @XmlElement(name = "UserId", required = true)
    protected String userId;
    @XmlElement(name = "UserRole", required = true)
    protected String userRole;
    @XmlElement(name = "BondId", required = true)
    protected String bondId;
    @XmlElement(name = "ButtonType", required = true)
    protected String buttonType;

    /**
     * Gets the value of the userId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserId() {
        return userId;
    }

    /**
     * Sets the value of the userId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserId(String value) {
        this.userId = value;
    }

    /**
     * Gets the value of the userRole property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserRole() {
        return userRole;
    }

    /**
     * Sets the value of the userRole property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserRole(String value) {
        this.userRole = value;
    }

    /**
     * Gets the value of the bondId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBondId() {
        return bondId;
    }

    /**
     * Sets the value of the bondId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBondId(String value) {
        this.bondId = value;
    }

    /**
     * Gets the value of the buttonType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getButtonType() {
        return buttonType;
    }

    /**
     * Sets the value of the buttonType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setButtonType(String value) {
        this.buttonType = value;
    }

}
