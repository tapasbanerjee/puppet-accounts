
package com.updatetask.types;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Policy complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Policy">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="PolicyId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="CustomerId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="PolicyStatus" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="PolicyIssueDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="PolicyEffectiveDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="PolicyCountry" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="PolicyGeneralConditions" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="PolicyParticularConditions" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="PolicyNotice" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="BondDtl" type="{https://group.atradius.com}Bond" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Policy", propOrder = {
    "policyId",
    "customerId",
    "policyStatus",
    "policyIssueDate",
    "policyEffectiveDate",
    "policyCountry",
    "policyGeneralConditions",
    "policyParticularConditions",
    "policyNotice",
    "bondDtl"
})
public class Policy {

    @XmlElement(name = "PolicyId", required = true)
    protected String policyId;
    @XmlElement(name = "CustomerId", required = true)
    protected String customerId;
    @XmlElement(name = "PolicyStatus", required = true)
    protected String policyStatus;
    @XmlElement(name = "PolicyIssueDate", required = true)
    protected String policyIssueDate;
    @XmlElement(name = "PolicyEffectiveDate", required = true)
    protected String policyEffectiveDate;
    @XmlElement(name = "PolicyCountry", required = true)
    protected String policyCountry;
    @XmlElement(name = "PolicyGeneralConditions", required = true)
    protected String policyGeneralConditions;
    @XmlElement(name = "PolicyParticularConditions", required = true)
    protected String policyParticularConditions;
    @XmlElement(name = "PolicyNotice", required = true)
    protected String policyNotice;
    @XmlElement(name = "BondDtl")
    protected List<Bond> bondDtl;

    /**
     * Gets the value of the policyId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPolicyId() {
        return policyId;
    }

    /**
     * Sets the value of the policyId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPolicyId(String value) {
        this.policyId = value;
    }

    /**
     * Gets the value of the customerId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustomerId() {
        return customerId;
    }

    /**
     * Sets the value of the customerId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustomerId(String value) {
        this.customerId = value;
    }

    /**
     * Gets the value of the policyStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPolicyStatus() {
        return policyStatus;
    }

    /**
     * Sets the value of the policyStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPolicyStatus(String value) {
        this.policyStatus = value;
    }

    /**
     * Gets the value of the policyIssueDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPolicyIssueDate() {
        return policyIssueDate;
    }

    /**
     * Sets the value of the policyIssueDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPolicyIssueDate(String value) {
        this.policyIssueDate = value;
    }

    /**
     * Gets the value of the policyEffectiveDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPolicyEffectiveDate() {
        return policyEffectiveDate;
    }

    /**
     * Sets the value of the policyEffectiveDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPolicyEffectiveDate(String value) {
        this.policyEffectiveDate = value;
    }

    /**
     * Gets the value of the policyCountry property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPolicyCountry() {
        return policyCountry;
    }

    /**
     * Sets the value of the policyCountry property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPolicyCountry(String value) {
        this.policyCountry = value;
    }

    /**
     * Gets the value of the policyGeneralConditions property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPolicyGeneralConditions() {
        return policyGeneralConditions;
    }

    /**
     * Sets the value of the policyGeneralConditions property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPolicyGeneralConditions(String value) {
        this.policyGeneralConditions = value;
    }

    /**
     * Gets the value of the policyParticularConditions property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPolicyParticularConditions() {
        return policyParticularConditions;
    }

    /**
     * Sets the value of the policyParticularConditions property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPolicyParticularConditions(String value) {
        this.policyParticularConditions = value;
    }

    /**
     * Gets the value of the policyNotice property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPolicyNotice() {
        return policyNotice;
    }

    /**
     * Sets the value of the policyNotice property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPolicyNotice(String value) {
        this.policyNotice = value;
    }

    /**
     * Gets the value of the bondDtl property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the bondDtl property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getBondDtl().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Bond }
     * 
     * 
     */
    public List<Bond> getBondDtl() {
        if (bondDtl == null) {
            bondDtl = new ArrayList<Bond>();
        }
        return this.bondDtl;
    }

}
