@javax.xml.bind.annotation.XmlSchema(namespace = "https://group.atradius.com", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.updatetask.types;
