
package com.updatetask.types;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Beneficiary complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Beneficiary">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="BeneficiaryId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="BeneficiaryCompanyName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="BeneficiaryFirstName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="BeneficiaryLastName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="BeneficiaryAddress" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="BeneficiaryPostalCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="BeneficiaryCity" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="BeneficiaryCountry" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="BeneficiaryVAT" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="BeneficiaryGroupingId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="BeneficiaryStatus" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="BeneficiaryContactName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Beneficiary", propOrder = {
    "beneficiaryId",
    "beneficiaryCompanyName",
    "beneficiaryFirstName",
    "beneficiaryLastName",
    "beneficiaryAddress",
    "beneficiaryPostalCode",
    "beneficiaryCity",
    "beneficiaryCountry",
    "beneficiaryVAT",
    "beneficiaryGroupingId",
    "beneficiaryStatus",
    "beneficiaryContactName"
})
public class Beneficiary {

    @XmlElement(name = "BeneficiaryId", required = true)
    protected String beneficiaryId;
    @XmlElement(name = "BeneficiaryCompanyName", required = true)
    protected String beneficiaryCompanyName;
    @XmlElement(name = "BeneficiaryFirstName", required = true)
    protected String beneficiaryFirstName;
    @XmlElement(name = "BeneficiaryLastName", required = true)
    protected String beneficiaryLastName;
    @XmlElement(name = "BeneficiaryAddress", required = true)
    protected String beneficiaryAddress;
    @XmlElement(name = "BeneficiaryPostalCode", required = true)
    protected String beneficiaryPostalCode;
    @XmlElement(name = "BeneficiaryCity", required = true)
    protected String beneficiaryCity;
    @XmlElement(name = "BeneficiaryCountry", required = true)
    protected String beneficiaryCountry;
    @XmlElement(name = "BeneficiaryVAT", required = true)
    protected String beneficiaryVAT;
    @XmlElement(name = "BeneficiaryGroupingId", required = true)
    protected String beneficiaryGroupingId;
    @XmlElement(name = "BeneficiaryStatus", required = true)
    protected String beneficiaryStatus;
    @XmlElement(name = "BeneficiaryContactName", required = true)
    protected String beneficiaryContactName;

    /**
     * Gets the value of the beneficiaryId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBeneficiaryId() {
        return beneficiaryId;
    }

    /**
     * Sets the value of the beneficiaryId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBeneficiaryId(String value) {
        this.beneficiaryId = value;
    }

    /**
     * Gets the value of the beneficiaryCompanyName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBeneficiaryCompanyName() {
        return beneficiaryCompanyName;
    }

    /**
     * Sets the value of the beneficiaryCompanyName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBeneficiaryCompanyName(String value) {
        this.beneficiaryCompanyName = value;
    }

    /**
     * Gets the value of the beneficiaryFirstName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBeneficiaryFirstName() {
        return beneficiaryFirstName;
    }

    /**
     * Sets the value of the beneficiaryFirstName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBeneficiaryFirstName(String value) {
        this.beneficiaryFirstName = value;
    }

    /**
     * Gets the value of the beneficiaryLastName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBeneficiaryLastName() {
        return beneficiaryLastName;
    }

    /**
     * Sets the value of the beneficiaryLastName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBeneficiaryLastName(String value) {
        this.beneficiaryLastName = value;
    }

    /**
     * Gets the value of the beneficiaryAddress property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBeneficiaryAddress() {
        return beneficiaryAddress;
    }

    /**
     * Sets the value of the beneficiaryAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBeneficiaryAddress(String value) {
        this.beneficiaryAddress = value;
    }

    /**
     * Gets the value of the beneficiaryPostalCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBeneficiaryPostalCode() {
        return beneficiaryPostalCode;
    }

    /**
     * Sets the value of the beneficiaryPostalCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBeneficiaryPostalCode(String value) {
        this.beneficiaryPostalCode = value;
    }

    /**
     * Gets the value of the beneficiaryCity property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBeneficiaryCity() {
        return beneficiaryCity;
    }

    /**
     * Sets the value of the beneficiaryCity property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBeneficiaryCity(String value) {
        this.beneficiaryCity = value;
    }

    /**
     * Gets the value of the beneficiaryCountry property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBeneficiaryCountry() {
        return beneficiaryCountry;
    }

    /**
     * Sets the value of the beneficiaryCountry property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBeneficiaryCountry(String value) {
        this.beneficiaryCountry = value;
    }

    /**
     * Gets the value of the beneficiaryVAT property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBeneficiaryVAT() {
        return beneficiaryVAT;
    }

    /**
     * Sets the value of the beneficiaryVAT property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBeneficiaryVAT(String value) {
        this.beneficiaryVAT = value;
    }

    /**
     * Gets the value of the beneficiaryGroupingId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBeneficiaryGroupingId() {
        return beneficiaryGroupingId;
    }

    /**
     * Sets the value of the beneficiaryGroupingId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBeneficiaryGroupingId(String value) {
        this.beneficiaryGroupingId = value;
    }

    /**
     * Gets the value of the beneficiaryStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBeneficiaryStatus() {
        return beneficiaryStatus;
    }

    /**
     * Sets the value of the beneficiaryStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBeneficiaryStatus(String value) {
        this.beneficiaryStatus = value;
    }

    /**
     * Gets the value of the beneficiaryContactName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBeneficiaryContactName() {
        return beneficiaryContactName;
    }

    /**
     * Sets the value of the beneficiaryContactName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBeneficiaryContactName(String value) {
        this.beneficiaryContactName = value;
    }

}
