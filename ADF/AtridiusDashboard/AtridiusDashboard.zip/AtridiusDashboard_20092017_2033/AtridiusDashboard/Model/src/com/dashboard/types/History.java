
package com.dashboard.types;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for History complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="History">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="HistoryRow" maxOccurs="unbounded" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="Decision" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                   &lt;element name="Underwriter" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                   &lt;element name="DecisionDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "History", propOrder = {
    "historyRow"
})
public class History {

    @XmlElement(name = "HistoryRow")
    protected List<History.HistoryRow> historyRow;

    /**
     * Gets the value of the historyRow property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the historyRow property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getHistoryRow().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link History.HistoryRow }
     * 
     * 
     */
    public List<History.HistoryRow> getHistoryRow() {
        if (historyRow == null) {
            historyRow = new ArrayList<History.HistoryRow>();
        }
        return this.historyRow;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="Decision" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *         &lt;element name="Underwriter" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *         &lt;element name="DecisionDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "decision",
        "underwriter",
        "decisionDate"
    })
    public static class HistoryRow {

        @XmlElement(name = "Decision", required = true)
        protected String decision;
        @XmlElement(name = "Underwriter", required = true)
        protected String underwriter;
        @XmlElement(name = "DecisionDate", required = true)
        protected String decisionDate;

        /**
         * Gets the value of the decision property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getDecision() {
            return decision;
        }

        /**
         * Sets the value of the decision property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setDecision(String value) {
            this.decision = value;
        }

        /**
         * Gets the value of the underwriter property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getUnderwriter() {
            return underwriter;
        }

        /**
         * Sets the value of the underwriter property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setUnderwriter(String value) {
            this.underwriter = value;
        }

        /**
         * Gets the value of the decisionDate property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getDecisionDate() {
            return decisionDate;
        }

        /**
         * Sets the value of the decisionDate property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setDecisionDate(String value) {
            this.decisionDate = value;
        }

    }

}
