
package com.updatetask.types;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Case complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Case">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="CaseId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="CaseSpecification" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="CaseReference" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ExpectedDeliveryDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="FixedExpiryDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ExpectedExpiryDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Case", propOrder = {
    "caseId",
    "caseSpecification",
    "caseReference",
    "expectedDeliveryDate",
    "fixedExpiryDate",
    "expectedExpiryDate"
})
public class Case {

    @XmlElement(name = "CaseId", required = true)
    protected String caseId;
    @XmlElement(name = "CaseSpecification", required = true)
    protected String caseSpecification;
    @XmlElement(name = "CaseReference", required = true)
    protected String caseReference;
    @XmlElement(name = "ExpectedDeliveryDate", required = true)
    protected String expectedDeliveryDate;
    @XmlElement(name = "FixedExpiryDate", required = true)
    protected String fixedExpiryDate;
    @XmlElement(name = "ExpectedExpiryDate", required = true)
    protected String expectedExpiryDate;

    /**
     * Gets the value of the caseId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCaseId() {
        return caseId;
    }

    /**
     * Sets the value of the caseId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCaseId(String value) {
        this.caseId = value;
    }

    /**
     * Gets the value of the caseSpecification property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCaseSpecification() {
        return caseSpecification;
    }

    /**
     * Sets the value of the caseSpecification property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCaseSpecification(String value) {
        this.caseSpecification = value;
    }

    /**
     * Gets the value of the caseReference property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCaseReference() {
        return caseReference;
    }

    /**
     * Sets the value of the caseReference property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCaseReference(String value) {
        this.caseReference = value;
    }

    /**
     * Gets the value of the expectedDeliveryDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExpectedDeliveryDate() {
        return expectedDeliveryDate;
    }

    /**
     * Sets the value of the expectedDeliveryDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExpectedDeliveryDate(String value) {
        this.expectedDeliveryDate = value;
    }

    /**
     * Gets the value of the fixedExpiryDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFixedExpiryDate() {
        return fixedExpiryDate;
    }

    /**
     * Sets the value of the fixedExpiryDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFixedExpiryDate(String value) {
        this.fixedExpiryDate = value;
    }

    /**
     * Gets the value of the expectedExpiryDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExpectedExpiryDate() {
        return expectedExpiryDate;
    }

    /**
     * Sets the value of the expectedExpiryDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExpectedExpiryDate(String value) {
        this.expectedExpiryDate = value;
    }

}
