
package com.updatetask.types;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ReviewType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ReviewType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Product" maxOccurs="unbounded">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="ProductName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                   &lt;element name="ProductReviewLimitAmount" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="ClassReviewLimit" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ReviewType", propOrder = {
    "product",
    "classReviewLimit"
})
public class ReviewType {

    @XmlElement(name = "Product", required = true)
    protected List<ReviewType.Product> product;
    @XmlElement(name = "ClassReviewLimit", required = true)
    protected String classReviewLimit;

    /**
     * Gets the value of the product property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the product property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getProduct().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ReviewType.Product }
     * 
     * 
     */
    public List<ReviewType.Product> getProduct() {
        if (product == null) {
            product = new ArrayList<ReviewType.Product>();
        }
        return this.product;
    }

    /**
     * Gets the value of the classReviewLimit property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClassReviewLimit() {
        return classReviewLimit;
    }

    /**
     * Sets the value of the classReviewLimit property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClassReviewLimit(String value) {
        this.classReviewLimit = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="ProductName" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *         &lt;element name="ProductReviewLimitAmount" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "productName",
        "productReviewLimitAmount"
    })
    public static class Product {

        @XmlElement(name = "ProductName", required = true)
        protected String productName;
        @XmlElement(name = "ProductReviewLimitAmount", required = true)
        protected String productReviewLimitAmount;

        /**
         * Gets the value of the productName property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getProductName() {
            return productName;
        }

        /**
         * Sets the value of the productName property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setProductName(String value) {
            this.productName = value;
        }

        /**
         * Gets the value of the productReviewLimitAmount property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getProductReviewLimitAmount() {
            return productReviewLimitAmount;
        }

        /**
         * Sets the value of the productReviewLimitAmount property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setProductReviewLimitAmount(String value) {
            this.productReviewLimitAmount = value;
        }

    }

}
