
package com.dashboard.types;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Analysis complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Analysis">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="AnalysisId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="BondId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="CurrentBondingExposure" type="{https://group.atradius.com}CurrentBondingExposure"/>
 *         &lt;element name="ReviewLimits" type="{https://group.atradius.com}ReviewLimit"/>
 *         &lt;element name="BondLineParameters" type="{https://group.atradius.com}BondLineParameter"/>
 *         &lt;element name="EconomicalAnalysis" type="{https://group.atradius.com}EconomicalAnalysis"/>
 *         &lt;element name="History" type="{https://group.atradius.com}History"/>
 *         &lt;element name="UnderwriterOpinion">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="ExposureComments" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                   &lt;element name="Motive" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                   &lt;element name="Decisions" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                   &lt;element name="Conditions" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="UserId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Analysis", propOrder = {
    "analysisId",
    "bondId",
    "currentBondingExposure",
    "reviewLimits",
    "bondLineParameters",
    "economicalAnalysis",
    "history",
    "underwriterOpinion",
    "userId"
})
public class Analysis {

    @XmlElement(name = "AnalysisId", required = true)
    protected String analysisId;
    @XmlElement(name = "BondId", required = true)
    protected String bondId;
    @XmlElement(name = "CurrentBondingExposure", required = true)
    protected CurrentBondingExposure currentBondingExposure;
    @XmlElement(name = "ReviewLimits", required = true)
    protected ReviewLimit reviewLimits;
    @XmlElement(name = "BondLineParameters", required = true)
    protected BondLineParameter bondLineParameters;
    @XmlElement(name = "EconomicalAnalysis", required = true)
    protected EconomicalAnalysis economicalAnalysis;
    @XmlElement(name = "History", required = true)
    protected History history;
    @XmlElement(name = "UnderwriterOpinion", required = true)
    protected Analysis.UnderwriterOpinion underwriterOpinion;
    @XmlElement(name = "UserId", required = true)
    protected String userId;

    /**
     * Gets the value of the analysisId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAnalysisId() {
        return analysisId;
    }

    /**
     * Sets the value of the analysisId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAnalysisId(String value) {
        this.analysisId = value;
    }

    /**
     * Gets the value of the bondId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBondId() {
        return bondId;
    }

    /**
     * Sets the value of the bondId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBondId(String value) {
        this.bondId = value;
    }

    /**
     * Gets the value of the currentBondingExposure property.
     * 
     * @return
     *     possible object is
     *     {@link CurrentBondingExposure }
     *     
     */
    public CurrentBondingExposure getCurrentBondingExposure() {
        return currentBondingExposure;
    }

    /**
     * Sets the value of the currentBondingExposure property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrentBondingExposure }
     *     
     */
    public void setCurrentBondingExposure(CurrentBondingExposure value) {
        this.currentBondingExposure = value;
    }

    /**
     * Gets the value of the reviewLimits property.
     * 
     * @return
     *     possible object is
     *     {@link ReviewLimit }
     *     
     */
    public ReviewLimit getReviewLimits() {
        return reviewLimits;
    }

    /**
     * Sets the value of the reviewLimits property.
     * 
     * @param value
     *     allowed object is
     *     {@link ReviewLimit }
     *     
     */
    public void setReviewLimits(ReviewLimit value) {
        this.reviewLimits = value;
    }

    /**
     * Gets the value of the bondLineParameters property.
     * 
     * @return
     *     possible object is
     *     {@link BondLineParameter }
     *     
     */
    public BondLineParameter getBondLineParameters() {
        return bondLineParameters;
    }

    /**
     * Sets the value of the bondLineParameters property.
     * 
     * @param value
     *     allowed object is
     *     {@link BondLineParameter }
     *     
     */
    public void setBondLineParameters(BondLineParameter value) {
        this.bondLineParameters = value;
    }

    /**
     * Gets the value of the economicalAnalysis property.
     * 
     * @return
     *     possible object is
     *     {@link EconomicalAnalysis }
     *     
     */
    public EconomicalAnalysis getEconomicalAnalysis() {
        return economicalAnalysis;
    }

    /**
     * Sets the value of the economicalAnalysis property.
     * 
     * @param value
     *     allowed object is
     *     {@link EconomicalAnalysis }
     *     
     */
    public void setEconomicalAnalysis(EconomicalAnalysis value) {
        this.economicalAnalysis = value;
    }

    /**
     * Gets the value of the history property.
     * 
     * @return
     *     possible object is
     *     {@link History }
     *     
     */
    public History getHistory() {
        return history;
    }

    /**
     * Sets the value of the history property.
     * 
     * @param value
     *     allowed object is
     *     {@link History }
     *     
     */
    public void setHistory(History value) {
        this.history = value;
    }

    /**
     * Gets the value of the underwriterOpinion property.
     * 
     * @return
     *     possible object is
     *     {@link Analysis.UnderwriterOpinion }
     *     
     */
    public Analysis.UnderwriterOpinion getUnderwriterOpinion() {
        return underwriterOpinion;
    }

    /**
     * Sets the value of the underwriterOpinion property.
     * 
     * @param value
     *     allowed object is
     *     {@link Analysis.UnderwriterOpinion }
     *     
     */
    public void setUnderwriterOpinion(Analysis.UnderwriterOpinion value) {
        this.underwriterOpinion = value;
    }

    /**
     * Gets the value of the userId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserId() {
        return userId;
    }

    /**
     * Sets the value of the userId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserId(String value) {
        this.userId = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="ExposureComments" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *         &lt;element name="Motive" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *         &lt;element name="Decisions" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *         &lt;element name="Conditions" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "exposureComments",
        "motive",
        "decisions",
        "conditions"
    })
    public static class UnderwriterOpinion {

        @XmlElement(name = "ExposureComments", required = true)
        protected String exposureComments;
        @XmlElement(name = "Motive", required = true)
        protected String motive;
        @XmlElement(name = "Decisions", required = true)
        protected String decisions;
        @XmlElement(name = "Conditions", required = true)
        protected String conditions;

        /**
         * Gets the value of the exposureComments property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getExposureComments() {
            return exposureComments;
        }

        /**
         * Sets the value of the exposureComments property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setExposureComments(String value) {
            this.exposureComments = value;
        }

        /**
         * Gets the value of the motive property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getMotive() {
            return motive;
        }

        /**
         * Sets the value of the motive property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setMotive(String value) {
            this.motive = value;
        }

        /**
         * Gets the value of the decisions property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getDecisions() {
            return decisions;
        }

        /**
         * Sets the value of the decisions property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setDecisions(String value) {
            this.decisions = value;
        }

        /**
         * Gets the value of the conditions property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getConditions() {
            return conditions;
        }

        /**
         * Sets the value of the conditions property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setConditions(String value) {
            this.conditions = value;
        }

    }

}
