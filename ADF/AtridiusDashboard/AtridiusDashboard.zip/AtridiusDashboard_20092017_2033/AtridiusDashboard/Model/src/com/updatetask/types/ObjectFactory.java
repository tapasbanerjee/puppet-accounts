
package com.updatetask.types;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.updatetask.types package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _SingleString_QNAME = new QName("http://xmlns.oracle.com/singleString", "singleString");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.updatetask.types
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link Bond }
     * 
     */
    public Bond createBond() {
        return new Bond();
    }

    /**
     * Create an instance of {@link Exposure }
     * 
     */
    public Exposure createExposure() {
        return new Exposure();
    }

    /**
     * Create an instance of {@link History }
     * 
     */
    public History createHistory() {
        return new History();
    }

    /**
     * Create an instance of {@link ReviewType }
     * 
     */
    public ReviewType createReviewType() {
        return new ReviewType();
    }

    /**
     * Create an instance of {@link LineParameter }
     * 
     */
    public LineParameter createLineParameter() {
        return new LineParameter();
    }

    /**
     * Create an instance of {@link Analysis }
     * 
     */
    public Analysis createAnalysis() {
        return new Analysis();
    }

    /**
     * Create an instance of {@link TaxDutyBond }
     * 
     */
    public TaxDutyBond createTaxDutyBond() {
        return new TaxDutyBond();
    }

    /**
     * Create an instance of {@link Customer }
     * 
     */
    public Customer createCustomer() {
        return new Customer();
    }

    /**
     * Create an instance of {@link ADFInputType }
     * 
     */
    public ADFInputType createADFInputType() {
        return new ADFInputType();
    }

    /**
     * Create an instance of {@link ProcessResponse }
     * 
     */
    public ProcessResponse createProcessResponse() {
        return new ProcessResponse();
    }

    /**
     * Create an instance of {@link Document }
     * 
     */
    public Document createDocument() {
        return new Document();
    }

    /**
     * Create an instance of {@link CurrentBondingExposure }
     * 
     */
    public CurrentBondingExposure createCurrentBondingExposure() {
        return new CurrentBondingExposure();
    }

    /**
     * Create an instance of {@link com.updatetask.types.Product }
     * 
     */
    public com.updatetask.types.Product createProduct() {
        return new com.updatetask.types.Product();
    }

    /**
     * Create an instance of {@link BondLineParameterType }
     * 
     */
    public BondLineParameterType createBondLineParameterType() {
        return new BondLineParameterType();
    }

    /**
     * Create an instance of {@link Beneficiary }
     * 
     */
    public Beneficiary createBeneficiary() {
        return new Beneficiary();
    }

    /**
     * Create an instance of {@link BondLineParameter }
     * 
     */
    public BondLineParameter createBondLineParameter() {
        return new BondLineParameter();
    }

    /**
     * Create an instance of {@link ReviewLimit }
     * 
     */
    public ReviewLimit createReviewLimit() {
        return new ReviewLimit();
    }

    /**
     * Create an instance of {@link Policy }
     * 
     */
    public Policy createPolicy() {
        return new Policy();
    }

    /**
     * Create an instance of {@link Case }
     * 
     */
    public Case createCase() {
        return new Case();
    }

    /**
     * Create an instance of {@link Project }
     * 
     */
    public Project createProject() {
        return new Project();
    }

    /**
     * Create an instance of {@link ReviewLimitType }
     * 
     */
    public ReviewLimitType createReviewLimitType() {
        return new ReviewLimitType();
    }

    /**
     * Create an instance of {@link EconomicalAnalysis }
     * 
     */
    public EconomicalAnalysis createEconomicalAnalysis() {
        return new EconomicalAnalysis();
    }

    /**
     * Create an instance of {@link Bond.BondCategory }
     * 
     */
    public Bond.BondCategory createBondBondCategory() {
        return new Bond.BondCategory();
    }

    /**
     * Create an instance of {@link Exposure.Product }
     * 
     */
    public Exposure.Product createExposureProduct() {
        return new Exposure.Product();
    }

    /**
     * Create an instance of {@link History.HistoryRow }
     * 
     */
    public History.HistoryRow createHistoryHistoryRow() {
        return new History.HistoryRow();
    }

    /**
     * Create an instance of {@link ReviewType.Product }
     * 
     */
    public ReviewType.Product createReviewTypeProduct() {
        return new ReviewType.Product();
    }

    /**
     * Create an instance of {@link LineParameter.Product }
     * 
     */
    public LineParameter.Product createLineParameterProduct() {
        return new LineParameter.Product();
    }

    /**
     * Create an instance of {@link Analysis.UnderwriterOpinion }
     * 
     */
    public Analysis.UnderwriterOpinion createAnalysisUnderwriterOpinion() {
        return new Analysis.UnderwriterOpinion();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/singleString", name = "singleString")
    public JAXBElement<String> createSingleString(String value) {
        return new JAXBElement<String>(_SingleString_QNAME, String.class, null, value);
    }

}
