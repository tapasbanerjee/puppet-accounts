
package com.dashboard.types;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="TaxDutyBond" maxOccurs="unbounded">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="CustomerBond" type="{https://group.atradius.com}Customer"/>
 *                   &lt;element name="Analysis" type="{https://group.atradius.com}Analysis"/>
 *                   &lt;element name="AdditionalADFInputs" type="{https://group.atradius.com}ADFInputType"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "taxDutyBond"
})
@XmlRootElement(name = "processResponseTaskDetails")
public class ProcessResponseTaskDetails {

    @XmlElement(name = "TaxDutyBond", required = true)
    protected List<ProcessResponseTaskDetails.TaxDutyBond> taxDutyBond;

    /**
     * Gets the value of the taxDutyBond property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the taxDutyBond property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getTaxDutyBond().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ProcessResponseTaskDetails.TaxDutyBond }
     * 
     * 
     */
    public List<ProcessResponseTaskDetails.TaxDutyBond> getTaxDutyBond() {
        if (taxDutyBond == null) {
            taxDutyBond = new ArrayList<ProcessResponseTaskDetails.TaxDutyBond>();
        }
        return this.taxDutyBond;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="CustomerBond" type="{https://group.atradius.com}Customer"/>
     *         &lt;element name="Analysis" type="{https://group.atradius.com}Analysis"/>
     *         &lt;element name="AdditionalADFInputs" type="{https://group.atradius.com}ADFInputType"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "customerBond",
        "analysis",
        "additionalADFInputs"
    })
    public static class TaxDutyBond {

        @XmlElement(name = "CustomerBond", required = true)
        protected Customer customerBond;
        @XmlElement(name = "Analysis", required = true)
        protected Analysis analysis;
        @XmlElement(name = "AdditionalADFInputs", required = true)
        protected ADFInputType additionalADFInputs;

        /**
         * Gets the value of the customerBond property.
         * 
         * @return
         *     possible object is
         *     {@link Customer }
         *     
         */
        public Customer getCustomerBond() {
            return customerBond;
        }

        /**
         * Sets the value of the customerBond property.
         * 
         * @param value
         *     allowed object is
         *     {@link Customer }
         *     
         */
        public void setCustomerBond(Customer value) {
            this.customerBond = value;
        }

        /**
         * Gets the value of the analysis property.
         * 
         * @return
         *     possible object is
         *     {@link Analysis }
         *     
         */
        public Analysis getAnalysis() {
            return analysis;
        }

        /**
         * Sets the value of the analysis property.
         * 
         * @param value
         *     allowed object is
         *     {@link Analysis }
         *     
         */
        public void setAnalysis(Analysis value) {
            this.analysis = value;
        }

        /**
         * Gets the value of the additionalADFInputs property.
         * 
         * @return
         *     possible object is
         *     {@link ADFInputType }
         *     
         */
        public ADFInputType getAdditionalADFInputs() {
            return additionalADFInputs;
        }

        /**
         * Sets the value of the additionalADFInputs property.
         * 
         * @param value
         *     allowed object is
         *     {@link ADFInputType }
         *     
         */
        public void setAdditionalADFInputs(ADFInputType value) {
            this.additionalADFInputs = value;
        }

    }

}
