
package com.dashboard.types;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for LineParameter complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="LineParameter">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Product" maxOccurs="unbounded">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="ProductName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                   &lt;element name="ProductBLSublimit" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                   &lt;element name="ProductMaxIndDuration" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                   &lt;element name="ProductMaxIndAmount" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                   &lt;element name="ProductSpecificBondText" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="ClassBLSublimit" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ClassMaxIndAmount" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ClassMaxIndDuration" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ClassSpecificText" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "LineParameter", propOrder = {
    "product",
    "classBLSublimit",
    "classMaxIndAmount",
    "classMaxIndDuration",
    "classSpecificText"
})
public class LineParameter {

    @XmlElement(name = "Product", required = true)
    protected List<LineParameter.Product> product;
    @XmlElement(name = "ClassBLSublimit", required = true)
    protected String classBLSublimit;
    @XmlElement(name = "ClassMaxIndAmount", required = true)
    protected String classMaxIndAmount;
    @XmlElement(name = "ClassMaxIndDuration", required = true)
    protected String classMaxIndDuration;
    @XmlElement(name = "ClassSpecificText", required = true)
    protected String classSpecificText;

    /**
     * Gets the value of the product property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the product property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getProduct().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link LineParameter.Product }
     * 
     * 
     */
    public List<LineParameter.Product> getProduct() {
        if (product == null) {
            product = new ArrayList<LineParameter.Product>();
        }
        return this.product;
    }

    /**
     * Gets the value of the classBLSublimit property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClassBLSublimit() {
        return classBLSublimit;
    }

    /**
     * Sets the value of the classBLSublimit property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClassBLSublimit(String value) {
        this.classBLSublimit = value;
    }

    /**
     * Gets the value of the classMaxIndAmount property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClassMaxIndAmount() {
        return classMaxIndAmount;
    }

    /**
     * Sets the value of the classMaxIndAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClassMaxIndAmount(String value) {
        this.classMaxIndAmount = value;
    }

    /**
     * Gets the value of the classMaxIndDuration property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClassMaxIndDuration() {
        return classMaxIndDuration;
    }

    /**
     * Sets the value of the classMaxIndDuration property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClassMaxIndDuration(String value) {
        this.classMaxIndDuration = value;
    }

    /**
     * Gets the value of the classSpecificText property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClassSpecificText() {
        return classSpecificText;
    }

    /**
     * Sets the value of the classSpecificText property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClassSpecificText(String value) {
        this.classSpecificText = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="ProductName" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *         &lt;element name="ProductBLSublimit" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *         &lt;element name="ProductMaxIndDuration" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *         &lt;element name="ProductMaxIndAmount" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *         &lt;element name="ProductSpecificBondText" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "productName",
        "productBLSublimit",
        "productMaxIndDuration",
        "productMaxIndAmount",
        "productSpecificBondText"
    })
    public static class Product {

        @XmlElement(name = "ProductName", required = true)
        protected String productName;
        @XmlElement(name = "ProductBLSublimit", required = true)
        protected String productBLSublimit;
        @XmlElement(name = "ProductMaxIndDuration", required = true)
        protected String productMaxIndDuration;
        @XmlElement(name = "ProductMaxIndAmount", required = true)
        protected String productMaxIndAmount;
        @XmlElement(name = "ProductSpecificBondText", required = true)
        protected String productSpecificBondText;

        /**
         * Gets the value of the productName property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getProductName() {
            return productName;
        }

        /**
         * Sets the value of the productName property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setProductName(String value) {
            this.productName = value;
        }

        /**
         * Gets the value of the productBLSublimit property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getProductBLSublimit() {
            return productBLSublimit;
        }

        /**
         * Sets the value of the productBLSublimit property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setProductBLSublimit(String value) {
            this.productBLSublimit = value;
        }

        /**
         * Gets the value of the productMaxIndDuration property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getProductMaxIndDuration() {
            return productMaxIndDuration;
        }

        /**
         * Sets the value of the productMaxIndDuration property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setProductMaxIndDuration(String value) {
            this.productMaxIndDuration = value;
        }

        /**
         * Gets the value of the productMaxIndAmount property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getProductMaxIndAmount() {
            return productMaxIndAmount;
        }

        /**
         * Sets the value of the productMaxIndAmount property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setProductMaxIndAmount(String value) {
            this.productMaxIndAmount = value;
        }

        /**
         * Gets the value of the productSpecificBondText property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getProductSpecificBondText() {
            return productSpecificBondText;
        }

        /**
         * Sets the value of the productSpecificBondText property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setProductSpecificBondText(String value) {
            this.productSpecificBondText = value;
        }

    }

}
