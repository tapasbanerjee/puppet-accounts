
package com.dashboard.types;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Customer complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Customer">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="CustomerId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="CustomerName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="CustomerAddress" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="CustomerPostalCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="CustomerCity" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="CustomerCountry" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="CustomerVAT" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="CustomerStatus" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="CustomerContactName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="PolicyDtl" type="{https://group.atradius.com}Policy" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Customer", propOrder = {
    "customerId",
    "customerName",
    "customerAddress",
    "customerPostalCode",
    "customerCity",
    "customerCountry",
    "customerVAT",
    "customerStatus",
    "customerContactName",
    "policyDtl"
})
public class Customer {

    @XmlElement(name = "CustomerId", required = true)
    protected String customerId;
    @XmlElement(name = "CustomerName", required = true)
    protected String customerName;
    @XmlElement(name = "CustomerAddress", required = true)
    protected String customerAddress;
    @XmlElement(name = "CustomerPostalCode", required = true)
    protected String customerPostalCode;
    @XmlElement(name = "CustomerCity", required = true)
    protected String customerCity;
    @XmlElement(name = "CustomerCountry", required = true)
    protected String customerCountry;
    @XmlElement(name = "CustomerVAT", required = true)
    protected String customerVAT;
    @XmlElement(name = "CustomerStatus", required = true)
    protected String customerStatus;
    @XmlElement(name = "CustomerContactName", required = true)
    protected String customerContactName;
    @XmlElement(name = "PolicyDtl")
    protected List<Policy> policyDtl;

    /**
     * Gets the value of the customerId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustomerId() {
        return customerId;
    }

    /**
     * Sets the value of the customerId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustomerId(String value) {
        this.customerId = value;
    }

    /**
     * Gets the value of the customerName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustomerName() {
        return customerName;
    }

    /**
     * Sets the value of the customerName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustomerName(String value) {
        this.customerName = value;
    }

    /**
     * Gets the value of the customerAddress property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustomerAddress() {
        return customerAddress;
    }

    /**
     * Sets the value of the customerAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustomerAddress(String value) {
        this.customerAddress = value;
    }

    /**
     * Gets the value of the customerPostalCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustomerPostalCode() {
        return customerPostalCode;
    }

    /**
     * Sets the value of the customerPostalCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustomerPostalCode(String value) {
        this.customerPostalCode = value;
    }

    /**
     * Gets the value of the customerCity property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustomerCity() {
        return customerCity;
    }

    /**
     * Sets the value of the customerCity property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustomerCity(String value) {
        this.customerCity = value;
    }

    /**
     * Gets the value of the customerCountry property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustomerCountry() {
        return customerCountry;
    }

    /**
     * Sets the value of the customerCountry property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustomerCountry(String value) {
        this.customerCountry = value;
    }

    /**
     * Gets the value of the customerVAT property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustomerVAT() {
        return customerVAT;
    }

    /**
     * Sets the value of the customerVAT property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustomerVAT(String value) {
        this.customerVAT = value;
    }

    /**
     * Gets the value of the customerStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustomerStatus() {
        return customerStatus;
    }

    /**
     * Sets the value of the customerStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustomerStatus(String value) {
        this.customerStatus = value;
    }

    /**
     * Gets the value of the customerContactName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustomerContactName() {
        return customerContactName;
    }

    /**
     * Sets the value of the customerContactName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustomerContactName(String value) {
        this.customerContactName = value;
    }

    /**
     * Gets the value of the policyDtl property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the policyDtl property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPolicyDtl().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Policy }
     * 
     * 
     */
    public List<Policy> getPolicyDtl() {
        if (policyDtl == null) {
            policyDtl = new ArrayList<Policy>();
        }
        return this.policyDtl;
    }

}
