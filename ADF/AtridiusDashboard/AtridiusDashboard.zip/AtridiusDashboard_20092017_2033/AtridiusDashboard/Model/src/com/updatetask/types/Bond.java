
package com.updatetask.types;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Bond complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Bond">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="BondId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="PolicyId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ProductId" type="{https://group.atradius.com}Product"/>
 *         &lt;element name="BondStatus" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="BondRequestDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="BondExposure" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="BondGroupingId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="BondUWY" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="BondSpot" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="BondObligation" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="StandardDuration" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="BondNotice" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="BondType" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="BondCategory">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="BondSubCategory" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="Beneficiary" type="{https://group.atradius.com}Beneficiary"/>
 *         &lt;element name="Project" type="{https://group.atradius.com}Project"/>
 *         &lt;element name="Case" type="{https://group.atradius.com}Case"/>
 *         &lt;element name="Documents" type="{https://group.atradius.com}Document" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Bond", propOrder = {
    "bondId",
    "policyId",
    "productId",
    "bondStatus",
    "bondRequestDate",
    "bondExposure",
    "bondGroupingId",
    "bondUWY",
    "bondSpot",
    "bondObligation",
    "standardDuration",
    "bondNotice",
    "bondType",
    "bondCategory",
    "beneficiary",
    "project",
    "_case",
    "documents"
})
public class Bond {

    @XmlElement(name = "BondId", required = true)
    protected String bondId;
    @XmlElement(name = "PolicyId", required = true)
    protected String policyId;
    @XmlElement(name = "ProductId", required = true)
    protected Product productId;
    @XmlElement(name = "BondStatus", required = true)
    protected String bondStatus;
    @XmlElement(name = "BondRequestDate", required = true)
    protected String bondRequestDate;
    @XmlElement(name = "BondExposure", required = true)
    protected String bondExposure;
    @XmlElement(name = "BondGroupingId", required = true)
    protected String bondGroupingId;
    @XmlElement(name = "BondUWY", required = true)
    protected String bondUWY;
    @XmlElement(name = "BondSpot", required = true)
    protected String bondSpot;
    @XmlElement(name = "BondObligation", required = true)
    protected String bondObligation;
    @XmlElement(name = "StandardDuration", required = true)
    protected String standardDuration;
    @XmlElement(name = "BondNotice", required = true)
    protected String bondNotice;
    @XmlElement(name = "BondType", required = true)
    protected String bondType;
    @XmlElement(name = "BondCategory", required = true)
    protected Bond.BondCategory bondCategory;
    @XmlElement(name = "Beneficiary", required = true)
    protected Beneficiary beneficiary;
    @XmlElement(name = "Project", required = true)
    protected Project project;
    @XmlElement(name = "Case", required = true)
    protected Case _case;
    @XmlElement(name = "Documents")
    protected List<Document> documents;

    /**
     * Gets the value of the bondId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBondId() {
        return bondId;
    }

    /**
     * Sets the value of the bondId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBondId(String value) {
        this.bondId = value;
    }

    /**
     * Gets the value of the policyId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPolicyId() {
        return policyId;
    }

    /**
     * Sets the value of the policyId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPolicyId(String value) {
        this.policyId = value;
    }

    /**
     * Gets the value of the productId property.
     * 
     * @return
     *     possible object is
     *     {@link Product }
     *     
     */
    public Product getProductId() {
        return productId;
    }

    /**
     * Sets the value of the productId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Product }
     *     
     */
    public void setProductId(Product value) {
        this.productId = value;
    }

    /**
     * Gets the value of the bondStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBondStatus() {
        return bondStatus;
    }

    /**
     * Sets the value of the bondStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBondStatus(String value) {
        this.bondStatus = value;
    }

    /**
     * Gets the value of the bondRequestDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBondRequestDate() {
        return bondRequestDate;
    }

    /**
     * Sets the value of the bondRequestDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBondRequestDate(String value) {
        this.bondRequestDate = value;
    }

    /**
     * Gets the value of the bondExposure property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBondExposure() {
        return bondExposure;
    }

    /**
     * Sets the value of the bondExposure property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBondExposure(String value) {
        this.bondExposure = value;
    }

    /**
     * Gets the value of the bondGroupingId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBondGroupingId() {
        return bondGroupingId;
    }

    /**
     * Sets the value of the bondGroupingId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBondGroupingId(String value) {
        this.bondGroupingId = value;
    }

    /**
     * Gets the value of the bondUWY property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBondUWY() {
        return bondUWY;
    }

    /**
     * Sets the value of the bondUWY property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBondUWY(String value) {
        this.bondUWY = value;
    }

    /**
     * Gets the value of the bondSpot property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBondSpot() {
        return bondSpot;
    }

    /**
     * Sets the value of the bondSpot property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBondSpot(String value) {
        this.bondSpot = value;
    }

    /**
     * Gets the value of the bondObligation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBondObligation() {
        return bondObligation;
    }

    /**
     * Sets the value of the bondObligation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBondObligation(String value) {
        this.bondObligation = value;
    }

    /**
     * Gets the value of the standardDuration property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStandardDuration() {
        return standardDuration;
    }

    /**
     * Sets the value of the standardDuration property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStandardDuration(String value) {
        this.standardDuration = value;
    }

    /**
     * Gets the value of the bondNotice property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBondNotice() {
        return bondNotice;
    }

    /**
     * Sets the value of the bondNotice property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBondNotice(String value) {
        this.bondNotice = value;
    }

    /**
     * Gets the value of the bondType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBondType() {
        return bondType;
    }

    /**
     * Sets the value of the bondType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBondType(String value) {
        this.bondType = value;
    }

    /**
     * Gets the value of the bondCategory property.
     * 
     * @return
     *     possible object is
     *     {@link Bond.BondCategory }
     *     
     */
    public Bond.BondCategory getBondCategory() {
        return bondCategory;
    }

    /**
     * Sets the value of the bondCategory property.
     * 
     * @param value
     *     allowed object is
     *     {@link Bond.BondCategory }
     *     
     */
    public void setBondCategory(Bond.BondCategory value) {
        this.bondCategory = value;
    }

    /**
     * Gets the value of the beneficiary property.
     * 
     * @return
     *     possible object is
     *     {@link Beneficiary }
     *     
     */
    public Beneficiary getBeneficiary() {
        return beneficiary;
    }

    /**
     * Sets the value of the beneficiary property.
     * 
     * @param value
     *     allowed object is
     *     {@link Beneficiary }
     *     
     */
    public void setBeneficiary(Beneficiary value) {
        this.beneficiary = value;
    }

    /**
     * Gets the value of the project property.
     * 
     * @return
     *     possible object is
     *     {@link Project }
     *     
     */
    public Project getProject() {
        return project;
    }

    /**
     * Sets the value of the project property.
     * 
     * @param value
     *     allowed object is
     *     {@link Project }
     *     
     */
    public void setProject(Project value) {
        this.project = value;
    }

    /**
     * Gets the value of the case property.
     * 
     * @return
     *     possible object is
     *     {@link Case }
     *     
     */
    public Case getCase() {
        return _case;
    }

    /**
     * Sets the value of the case property.
     * 
     * @param value
     *     allowed object is
     *     {@link Case }
     *     
     */
    public void setCase(Case value) {
        this._case = value;
    }

    /**
     * Gets the value of the documents property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the documents property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDocuments().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Document }
     * 
     * 
     */
    public List<Document> getDocuments() {
        if (documents == null) {
            documents = new ArrayList<Document>();
        }
        return this.documents;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="BondSubCategory" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "bondSubCategory"
    })
    public static class BondCategory {

        @XmlElement(name = "BondSubCategory", required = true)
        protected String bondSubCategory;

        /**
         * Gets the value of the bondSubCategory property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getBondSubCategory() {
            return bondSubCategory;
        }

        /**
         * Sets the value of the bondSubCategory property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setBondSubCategory(String value) {
            this.bondSubCategory = value;
        }

    }

}
