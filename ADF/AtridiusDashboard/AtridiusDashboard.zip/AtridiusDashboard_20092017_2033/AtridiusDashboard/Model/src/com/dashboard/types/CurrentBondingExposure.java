
package com.dashboard.types;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for CurrentBondingExposure complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CurrentBondingExposure">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="GlobalBondingExposure" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="BondClass" type="{https://group.atradius.com}Exposure"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CurrentBondingExposure", propOrder = {
    "globalBondingExposure",
    "bondClass"
})
public class CurrentBondingExposure {

    @XmlElement(name = "GlobalBondingExposure", required = true)
    protected String globalBondingExposure;
    @XmlElement(name = "BondClass", required = true)
    protected Exposure bondClass;

    /**
     * Gets the value of the globalBondingExposure property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGlobalBondingExposure() {
        return globalBondingExposure;
    }

    /**
     * Sets the value of the globalBondingExposure property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGlobalBondingExposure(String value) {
        this.globalBondingExposure = value;
    }

    /**
     * Gets the value of the bondClass property.
     * 
     * @return
     *     possible object is
     *     {@link Exposure }
     *     
     */
    public Exposure getBondClass() {
        return bondClass;
    }

    /**
     * Sets the value of the bondClass property.
     * 
     * @param value
     *     allowed object is
     *     {@link Exposure }
     *     
     */
    public void setBondClass(Exposure value) {
        this.bondClass = value;
    }

}
