
package com.dashboard.types;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for BondLineParameter complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BondLineParameter">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="CurrentBLP" type="{https://group.atradius.com}BondLineParameterType"/>
 *         &lt;element name="ProposedBLP" type="{https://group.atradius.com}BondLineParameterType"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BondLineParameter", propOrder = {
    "currentBLP",
    "proposedBLP"
})
public class BondLineParameter {

    @XmlElement(name = "CurrentBLP", required = true)
    protected BondLineParameterType currentBLP;
    @XmlElement(name = "ProposedBLP", required = true)
    protected BondLineParameterType proposedBLP;

    /**
     * Gets the value of the currentBLP property.
     * 
     * @return
     *     possible object is
     *     {@link BondLineParameterType }
     *     
     */
    public BondLineParameterType getCurrentBLP() {
        return currentBLP;
    }

    /**
     * Sets the value of the currentBLP property.
     * 
     * @param value
     *     allowed object is
     *     {@link BondLineParameterType }
     *     
     */
    public void setCurrentBLP(BondLineParameterType value) {
        this.currentBLP = value;
    }

    /**
     * Gets the value of the proposedBLP property.
     * 
     * @return
     *     possible object is
     *     {@link BondLineParameterType }
     *     
     */
    public BondLineParameterType getProposedBLP() {
        return proposedBLP;
    }

    /**
     * Sets the value of the proposedBLP property.
     * 
     * @param value
     *     allowed object is
     *     {@link BondLineParameterType }
     *     
     */
    public void setProposedBLP(BondLineParameterType value) {
        this.proposedBLP = value;
    }

}
