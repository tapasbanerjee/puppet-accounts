
package com.updatetask.types;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Product complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Product">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ProductId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="BondClass" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Product" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="BondStandardText" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="BondCustomText" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="BondAmount" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="BondCurrency" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="BondStartDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="BondEndDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Product", propOrder = {
    "productId",
    "bondClass",
    "product",
    "bondStandardText",
    "bondCustomText",
    "bondAmount",
    "bondCurrency",
    "bondStartDate",
    "bondEndDate"
})
public class Product {

    @XmlElement(name = "ProductId", required = true)
    protected String productId;
    @XmlElement(name = "BondClass", required = true)
    protected String bondClass;
    @XmlElement(name = "Product", required = true)
    protected String product;
    @XmlElement(name = "BondStandardText", required = true)
    protected String bondStandardText;
    @XmlElement(name = "BondCustomText", required = true)
    protected String bondCustomText;
    @XmlElement(name = "BondAmount", required = true)
    protected String bondAmount;
    @XmlElement(name = "BondCurrency", required = true)
    protected String bondCurrency;
    @XmlElement(name = "BondStartDate", required = true)
    protected String bondStartDate;
    @XmlElement(name = "BondEndDate", required = true)
    protected String bondEndDate;

    /**
     * Gets the value of the productId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductId() {
        return productId;
    }

    /**
     * Sets the value of the productId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductId(String value) {
        this.productId = value;
    }

    /**
     * Gets the value of the bondClass property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBondClass() {
        return bondClass;
    }

    /**
     * Sets the value of the bondClass property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBondClass(String value) {
        this.bondClass = value;
    }

    /**
     * Gets the value of the product property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProduct() {
        return product;
    }

    /**
     * Sets the value of the product property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProduct(String value) {
        this.product = value;
    }

    /**
     * Gets the value of the bondStandardText property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBondStandardText() {
        return bondStandardText;
    }

    /**
     * Sets the value of the bondStandardText property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBondStandardText(String value) {
        this.bondStandardText = value;
    }

    /**
     * Gets the value of the bondCustomText property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBondCustomText() {
        return bondCustomText;
    }

    /**
     * Sets the value of the bondCustomText property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBondCustomText(String value) {
        this.bondCustomText = value;
    }

    /**
     * Gets the value of the bondAmount property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBondAmount() {
        return bondAmount;
    }

    /**
     * Sets the value of the bondAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBondAmount(String value) {
        this.bondAmount = value;
    }

    /**
     * Gets the value of the bondCurrency property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBondCurrency() {
        return bondCurrency;
    }

    /**
     * Sets the value of the bondCurrency property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBondCurrency(String value) {
        this.bondCurrency = value;
    }

    /**
     * Gets the value of the bondStartDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBondStartDate() {
        return bondStartDate;
    }

    /**
     * Sets the value of the bondStartDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBondStartDate(String value) {
        this.bondStartDate = value;
    }

    /**
     * Gets the value of the bondEndDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBondEndDate() {
        return bondEndDate;
    }

    /**
     * Sets the value of the bondEndDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBondEndDate(String value) {
        this.bondEndDate = value;
    }

}
